﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Generic_Collection
{
    class Program
    {
        static void Main(string[] args)
        {
            College c = new College(1, "pathfront");
            bool flag = true;
            while(flag)
            {
                Console.WriteLine("enter your operation:1-Add,2-Find,3-Remove,4-Show,5-exit,6-leave");
                int opt = Convert.ToInt32(Console.ReadLine());
                switch (opt)
                {
                    case 1:
                        Console.WriteLine("enter student name:");
                        string name = Console.ReadLine();
                        Console.WriteLine("enter student city:");
                        string city = Console.ReadLine();
                        Student s = new Student(name, city);
                        c.AddStudent(s);
                        Console.WriteLine("student added:" + s.PStudentId);
                        break;
                    case 2:
                        Console.WriteLine("Enter student id:");
                        int ID = Convert.ToInt32(Console.ReadLine());
                        Student obj = c.Find(ID);
                        if (obj != null)
                        {
                            Console.WriteLine(obj.PStudentcity + " " + obj.PStudentname);
                        }
                        else
                        {
                            Console.WriteLine("student not found:");
                        }
                        break;
                    case 3:
                        Console.WriteLine("enter student id:");
                        int SID = Convert.ToInt32(Console.ReadLine());
                        bool status = c.Remove(SID);
                        if(status)
                        {
                            Console.WriteLine("student removes:");

                        }
                        else
                        {
                            Console.WriteLine("student not found:");
                        }
                        break;
                    case 4:
                        c.ShowAll();
                        break;
                    case 5:
                        flag = false;
                        break;
                    case 6:
                        Console.WriteLine("eneter student id:");
                        int stid = Convert.ToInt32(Console.ReadLine());
                        Student sobj = c.Find(stid);
                        Console.WriteLine("enter reason:");
                        string reason = Console.ReadLine();
                        sobj.TakeLeave(reason);
                        break;
                        
                   
                }
            }


        }
    }
}
