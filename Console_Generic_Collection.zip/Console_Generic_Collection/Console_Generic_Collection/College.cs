﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Generic_Collection
{
    class College
    {

        public void onLeave(int ID,string reason)
        {
            Console.WriteLine("college class:student on leave:" + ID + " ," + reason);
        }
        private int CollegeId;
        private string Collegename;

        public College(int CollegeId,string Collegename)
        {
            this.CollegeId = CollegeId;
            this.Collegename = Collegename;
            
        }
        private List<Student> Studentlist = new List<Student>();
        public void AddStudent(Student st)
        {
            Student.delLeave d = new Student.delLeave(this.onLeave);
            Studentlist.Add(st);//association
        }
        public Student Find(int ID)
        {
            foreach(Student s in Studentlist)
            {
                if(s.PStudentId==ID)
                {
                    return s;
                }
            }
            return null;
        }
        public bool Remove(int ID)
        {
            foreach(Student s in Studentlist)
            {
                if(s.PStudentId==ID)
                {
                    Studentlist.Remove(s);
                    return true;
                }
            }
            return false;
        }
        public void ShowAll()
        {
            foreach(Student s in Studentlist)
            {
                Console.WriteLine(s.PStudentId + " " + s.PStudentname + " " + s.PStudentcity);
            }
        }

    }
}
