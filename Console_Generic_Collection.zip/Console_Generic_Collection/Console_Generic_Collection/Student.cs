﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Generic_Collection
{
    class Student
    {
        public delegate void delLeave(int id, string reason);
        public event delLeave evtleave;

        private int StudentID;
        private string Studentname;
        private string Studentcity;
        private static int count = 1000;

        public Student(string Studentname,string Studentcity)
        {
            Student.count++;
            this.StudentID = Student.count;
            this.Studentname = Studentname;
            this.Studentcity = Studentcity;

        }
        public int PStudentId
        { get { return this.StudentID; } }
        public string PStudentname
        { get { return this.Studentname; } }
        public string PStudentcity
        { get { return this.Studentcity; } }
        public void TakeLeave(string Reason)
        {
            if (this.evtleave != null)

            {
                this.evtleave(this.StudentID, Reason);
            }
            Console.WriteLine("student on leave:" + this.StudentID +",Reason:"+Reason);
        }


    }
}
