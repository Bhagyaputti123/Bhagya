﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;


namespace Console_linq_xml
{
    class Program
    {
        static void Main(string[] args)
        {
            XElement orders = new XElement("Orders", new XElement("Order", new XElement("orderid", "1001"),
                                                                        new XElement("customername", "XYZ"),
                                                                        new XElement("orderAmount", "20000")),

                                                  new XElement("Order", new XElement("orderid", "1002"),
                                                  new XElement("customername", "ABC"),
                                                  new XElement("orderAmount", "30000")));

            orders.Save(@"C:/XML prgms/orders.xml");
            Console.WriteLine("XML file created");




            /*string url = @"C:\C# programs day1_basics\Console_linq_xml\Console_linq_xml\Customer.xml";

            XDocument doc = XDocument.Load(url);

            var data = from x in doc.Descendants("customer")
                       select new
                       {
                           cid = x.Element("customerID").Value,
                           cName = x.Element("customerName").Value,
                           ccity = x.Element("customerCity").Value
                       };

             foreach(var d in data)
            {
                Console.WriteLine(d.cid + "" + d.cName + " " + d.ccity);
            }
            */
            Console.ReadLine();




       }
    }
}
