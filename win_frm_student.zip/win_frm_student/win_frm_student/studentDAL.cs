﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
namespace win_frm_student
{
    class studentDAL
    {
        SqlConnection con = new SqlConnection
            (ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public int AddStudent(Student st)
        {
            SqlCommand com_student_insert = new SqlCommand
           ("insert tbl_students values(@name,@city,@address,getdate())", con);
            com_student_insert.Parameters.AddWithValue("@name", st.studentname);
            com_student_insert.Parameters.AddWithValue("@city", st.studentcity);
            com_student_insert.Parameters.AddWithValue("@address", st.studentaddress);
            com_student_insert.Parameters.AddWithValue("@emailID", st.studentemailid);
            con.Open();
            com_student_insert.ExecuteNonQuery();
            SqlCommand com_id = new SqlCommand("select @@identity", con);
            int ID = Convert.ToInt32(com_id.ExecuteScalar());
            con.Close();
            return ID;

        }
        public string Find(int ID)
        {
            SqlCommand com_find = new SqlCommand
                ("select * from tbl_students where studentid=@id", con);
            com_find.Parameters.AddWithValue("@id", ID);
            con.Open();
            SqlDataReader rd = com_find.ExecuteReader();
            if (rd.Read())
            {
                Student ST = new Student();
                ST.studentID = rd.GetInt32(0);
                ST.studentname = rd.GetString(1);
                ST.studentcity = rd.GetString(2);
                ST.studentaddress = rd.GetString(3);
                ST.studentemailid = rd.GetString(4);
                con.Close();
                return ST;
            }
            else
            {
                return null;
            }

        }
        public bool update(int ID, string Address, string Mobileno)
        {
            SqlCommand com_update = new SqlCommand("update  tbl_students set studentaddress=@address,studentmobileno=@mobileno where studentid=@id", con);
            com_update.Parameters.AddWithValue("@id", ID);
            com_update.Parameters.AddWithValue("@address",Address );
            com_update.Parameters.AddWithValue("@Mobileno", Mobileno);
            con.Open();
            int count = com_update.ExecuteNonQuery();
            con.Close();
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
             }
        }

        public bool delete(int ID)
        {
            SqlCommand com_delete = new SqlCommand("delete  tbl_students where studentid=@id", con);
            com_delete.Parameters.AddWithValue("@id", ID);
            con.Open();
            int count = com_delete.ExecuteNonQuery();
            con.Close();
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    
    }
}

