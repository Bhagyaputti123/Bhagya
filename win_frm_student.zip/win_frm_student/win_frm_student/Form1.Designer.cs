﻿namespace win_frm_student
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_sid = new System.Windows.Forms.Label();
            this.lbl_sname = new System.Windows.Forms.Label();
            this.lbl_scity = new System.Windows.Forms.Label();
            this.lbl_saddress = new System.Windows.Forms.Label();
            this.lbl_semailid = new System.Windows.Forms.Label();
            this.txt_sid = new System.Windows.Forms.TextBox();
            this.txt_sname = new System.Windows.Forms.TextBox();
            this.txt_scity = new System.Windows.Forms.TextBox();
            this.txt_address = new System.Windows.Forms.TextBox();
            this.txt_semailid = new System.Windows.Forms.TextBox();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_find = new System.Windows.Forms.Button();
            this.btn_pdate = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_sid
            // 
            this.lbl_sid.AutoSize = true;
            this.lbl_sid.Location = new System.Drawing.Point(68, 44);
            this.lbl_sid.Name = "lbl_sid";
            this.lbl_sid.Size = new System.Drawing.Size(58, 13);
            this.lbl_sid.TabIndex = 0;
            this.lbl_sid.Text = "StudentID:";
            // 
            // lbl_sname
            // 
            this.lbl_sname.AutoSize = true;
            this.lbl_sname.Location = new System.Drawing.Point(68, 85);
            this.lbl_sname.Name = "lbl_sname";
            this.lbl_sname.Size = new System.Drawing.Size(75, 13);
            this.lbl_sname.TabIndex = 1;
            this.lbl_sname.Text = "StudentName:";
            // 
            // lbl_scity
            // 
            this.lbl_scity.AutoSize = true;
            this.lbl_scity.Location = new System.Drawing.Point(71, 137);
            this.lbl_scity.Name = "lbl_scity";
            this.lbl_scity.Size = new System.Drawing.Size(64, 13);
            this.lbl_scity.TabIndex = 2;
            this.lbl_scity.Text = "StudentCity:";
            this.lbl_scity.Click += new System.EventHandler(this.label3_Click);
            // 
            // lbl_saddress
            // 
            this.lbl_saddress.AutoSize = true;
            this.lbl_saddress.Location = new System.Drawing.Point(71, 187);
            this.lbl_saddress.Name = "lbl_saddress";
            this.lbl_saddress.Size = new System.Drawing.Size(85, 13);
            this.lbl_saddress.TabIndex = 3;
            this.lbl_saddress.Text = "StudentAddress:";
            this.lbl_saddress.Click += new System.EventHandler(this.label4_Click);
            // 
            // lbl_semailid
            // 
            this.lbl_semailid.AutoSize = true;
            this.lbl_semailid.Location = new System.Drawing.Point(71, 234);
            this.lbl_semailid.Name = "lbl_semailid";
            this.lbl_semailid.Size = new System.Drawing.Size(83, 13);
            this.lbl_semailid.TabIndex = 4;
            this.lbl_semailid.Text = "StudentEmailID:";
            // 
            // txt_sid
            // 
            this.txt_sid.Location = new System.Drawing.Point(252, 44);
            this.txt_sid.Name = "txt_sid";
            this.txt_sid.Size = new System.Drawing.Size(183, 20);
            this.txt_sid.TabIndex = 5;
            // 
            // txt_sname
            // 
            this.txt_sname.Location = new System.Drawing.Point(252, 85);
            this.txt_sname.Name = "txt_sname";
            this.txt_sname.Size = new System.Drawing.Size(183, 20);
            this.txt_sname.TabIndex = 6;
            // 
            // txt_scity
            // 
            this.txt_scity.Location = new System.Drawing.Point(252, 130);
            this.txt_scity.Name = "txt_scity";
            this.txt_scity.Size = new System.Drawing.Size(183, 20);
            this.txt_scity.TabIndex = 7;
            // 
            // txt_address
            // 
            this.txt_address.Location = new System.Drawing.Point(252, 180);
            this.txt_address.Name = "txt_address";
            this.txt_address.Size = new System.Drawing.Size(183, 20);
            this.txt_address.TabIndex = 8;
            this.txt_address.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // txt_semailid
            // 
            this.txt_semailid.Location = new System.Drawing.Point(252, 234);
            this.txt_semailid.Name = "txt_semailid";
            this.txt_semailid.Size = new System.Drawing.Size(183, 20);
            this.txt_semailid.TabIndex = 9;
            this.txt_semailid.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(13, 324);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(75, 23);
            this.btn_add.TabIndex = 10;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_find
            // 
            this.btn_find.Location = new System.Drawing.Point(127, 323);
            this.btn_find.Name = "btn_find";
            this.btn_find.Size = new System.Drawing.Size(75, 23);
            this.btn_find.TabIndex = 11;
            this.btn_find.Text = "Find";
            this.btn_find.UseVisualStyleBackColor = true;
            this.btn_find.Click += new System.EventHandler(this.btn_find_Click);
            // 
            // btn_pdate
            // 
            this.btn_pdate.Location = new System.Drawing.Point(242, 323);
            this.btn_pdate.Name = "btn_pdate";
            this.btn_pdate.Size = new System.Drawing.Size(75, 23);
            this.btn_pdate.TabIndex = 12;
            this.btn_pdate.Text = "Update";
            this.btn_pdate.UseVisualStyleBackColor = true;
            this.btn_pdate.Click += new System.EventHandler(this.btn_pdate_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(377, 322);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(75, 23);
            this.btn_delete.TabIndex = 13;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(489, 413);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_pdate);
            this.Controls.Add(this.btn_find);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.txt_semailid);
            this.Controls.Add(this.txt_address);
            this.Controls.Add(this.txt_scity);
            this.Controls.Add(this.txt_sname);
            this.Controls.Add(this.txt_sid);
            this.Controls.Add(this.lbl_semailid);
            this.Controls.Add(this.lbl_saddress);
            this.Controls.Add(this.lbl_scity);
            this.Controls.Add(this.lbl_sname);
            this.Controls.Add(this.lbl_sid);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_sid;
        private System.Windows.Forms.Label lbl_sname;
        private System.Windows.Forms.Label lbl_scity;
        private System.Windows.Forms.Label lbl_saddress;
        private System.Windows.Forms.Label lbl_semailid;
        private System.Windows.Forms.TextBox txt_sid;
        private System.Windows.Forms.TextBox txt_sname;
        private System.Windows.Forms.TextBox txt_scity;
        private System.Windows.Forms.TextBox txt_address;
        private System.Windows.Forms.TextBox txt_semailid;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_find;
        private System.Windows.Forms.Button btn_pdate;
        private System.Windows.Forms.Button btn_delete;
    }
}

