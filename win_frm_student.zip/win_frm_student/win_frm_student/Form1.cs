﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_frm_student
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            if (txt_sname.Text == string.Empty)
            {
                MessageBox.Show("enter name:");
            }
            else if (txt_scity.Text == string.Empty)
            {
                MessageBox.Show("enter city:");

            }
            else if (txt_address.Text == string.Empty)
            {
                MessageBox.Show("enter address:");
            }
            else if (txt_semailid.Text == string.Empty)
            {
                MessageBox.Show("enter email id:");
            }

            else
            {
                string name = txt_sname.Text;
                string city = txt_scity.Text;
                string address = txt_address.Text;
                string emailid = txt_semailid.Text;
                Student obj = new Student();
                obj.studentname = name;
                obj.studentcity = city;
                obj.studentaddress = address;
                obj.studentemailid = emailid;

                
                int id = dal.AddStudent(obj);
                MessageBox.Show("student added:" + id);

            }
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            if (txt_sid.Text == string.Empty)

            {
                MessageBox.Show("enter id:");
            }
            else
            {
                int ID = Convert.ToInt32(txt_sid.Text);
                studentDAL dal = new studentDAL();
                Student s1 = dal.Find(ID);
                if (s1 != null)
                {
                    txt_sname.Text = s1.studentname;
                    txt_scity.Text = s1.studentcity;
                    txt_address.Text = s1.studentpassword;
                    txt_semailid.Text = s1.studentDOJ.ToString();

                }
                else
                {
                    MessageBox.Show("not found");
                }
            }
        }

        private void btn_pdate_Click(object sender, EventArgs e)
        {
            if (txt_sid.Text == string.Empty)
            {
                MessageBox.Show("enter id:");

            }
            else if (txt_scity.Text == string.Empty)
            {
                MessageBox.Show("enter city");
            }
            else if (txt_address.Text == string.Empty)
            {
                MessageBox.Show("enter address");
            }
            else if (txt_semailid.Text == string.Empty)
            {
                MessageBox.Show("enter mailid");
            }
            else
            {

                int ID = Convert.ToInt32(txt_sid.Text);
                string city = txt_scity.Text;
                string address = txt_address.Text;
                string emailid = txt_semailid.Text;

                studentDAL dal = new studentDAL();
                bool status = dal.update(ID, city,address,emailid);
                if (status)
                {
                    MessageBox.Show("updated");
                }
                else
                {
                    MessageBox.Show("not updated");
                }
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if(txt_sid.Text == string.Empty)
            {
                MessageBox.Show("enter id");

            }
            else
            {
                int ID = Convert.ToInt32(txt_sid.Text);
                studentDAL dal = new studentDAL();
                bool status = dal.delete(ID);
                if (status)
                {
                    MessageBox.Show("deleted");

                }
                else
                {
                    MessageBox.Show("not deleted");
                }
            }
        }

    }
}




