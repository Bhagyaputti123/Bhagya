﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cosole_op_singleton
{
    class Program
    {
        static void Main(string[] args)
        {
            Manager m1 = Manager.Getmanager();
            Manager m2 = Manager.Getmanager();
            if(m1==m2)
            {
                Console.WriteLine("single ton");

            }
            else
            {
                Console.WriteLine("not a single ton");
            }

        }
    }
}
