﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cosole_op_singleton
{
    class Manager
    {
        private int managerid;
        private string managername;
        public int pmanagerid { get { return this.managerid; } }
        public string pmanagername { get { return this.managername; } }
        public Manager(int managerid,string managername)
        {
            this.managerid = managerid;
            this.managername = managername;
        }
        static Manager m;
        public static Manager Getmanager()
        {
            if (m == null)
            {
                Manager m = new Manager(101, "abc");
            }
            return m;
        }

    }
}
