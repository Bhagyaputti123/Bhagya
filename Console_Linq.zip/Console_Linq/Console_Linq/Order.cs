﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Linq
{
    class Order
    {
        public int OrderID { get; set; }
        public int customerID { get; set; }
        public string ItemName { get; set; }
        public int ItemPrice { get; set; }


    }
}
