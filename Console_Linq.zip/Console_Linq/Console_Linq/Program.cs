﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Linq
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Customer> cuslist = new List<Customer>();
            cuslist.Add(new Customer { customerID = 1, customerAge = 25, customeercity = "BGL", customerName = "ABC" });
            cuslist.Add(new Customer { customerID = 2, customerAge = 22, customeercity = "XYZ", customerName = "bhagya" });
            cuslist.Add(new Customer { customerID = 3, customerAge = 26, customeercity = "pune", customerName = "roja" });
            cuslist.Add(new Customer { customerID = 4, customerAge = 27, customeercity = "kodagu", customerName = "madhu" });
            cuslist.Add(new Customer { customerID = 5, customerAge = 22, customeercity = "mumbai", customerName = "nayana" });

            List<Order> Ordlist = new List<Order>();
            Ordlist.Add(new Order { OrderID = 1001, customerID = 1, ItemName = "oneplus 6" ,ItemPrice=10000});
            Ordlist.Add(new Order { OrderID = 1002, customerID = 1, ItemName = "Tv", ItemPrice = 350 });
            Ordlist.Add(new Order { OrderID = 1003, customerID = 2, ItemName = "oneplus6T", ItemPrice = 40000 });
            Ordlist.Add(new Order { OrderID = 1004, customerID = 4, ItemName = "laptop", ItemPrice = 30000 });

            string city = "BGL";
            var q = from c in cuslist
                    where c.customeercity == city
                    orderby c.customerAge descending,c.customerName ascending
                    select c;
            foreach(var x in q)
            {
                Console.WriteLine(x.customerID + " " + x.customerName + " " + x.customerAge);

            }
            var count = (from c in cuslist
                         where c.customeercity == city
                         select c).Count();
            Console.WriteLine(count);

            var obj = (from c in cuslist
                       where c.customerID == 1
                       select c).FirstOrDefault();
            if(obj!=null)
                {
                Console.WriteLine(obj.customerID + " " + obj.customerName);

            }
            else
            {
                Console.WriteLine("not found");
            }
            var qdata = from c in cuslist
                         where c.customerAge > 20
                         select new { cid = c.customerID, cname = c.customerName, ccity = c.customeercity };
            foreach(var p in qdata)
            {
                Console.WriteLine(p.cid + " " + p.cname + " " + p.ccity);//projection of data
            }

            var joindata = from c in cuslist
                           join o in Ordlist
                           on c.customerID equals o.customerID
                           select new { cid = c.customerID, cname = c.customerName, oid = o.OrderID, iname = o.ItemName, iprice = o.ItemPrice };
            //dg_custmers.datasource=joindata
            foreach(var j in joindata)
            {
                Console.WriteLine(j.cid + " " + j.cname + " " + j.oid + " " + j.iname + " " + j.iprice);

            }





            Console.ReadLine();
        }
    }
}
