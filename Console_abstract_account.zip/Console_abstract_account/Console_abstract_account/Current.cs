﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_abstract_account
{
    class Current:Account
    {
        public Current(int accountId,string customername,int AccountBalance)
            :base(accountId,customername,AccountBalance)
        {
            Console.WriteLine("Current account constructor");
        }

        public override void deposit(int amt)
        {
            this.AccountBalance += amt + 100;
        }

        public override void withdraw(int amt)
        {
            this.AccountBalance -= amt + 10;
        }
    }
}
