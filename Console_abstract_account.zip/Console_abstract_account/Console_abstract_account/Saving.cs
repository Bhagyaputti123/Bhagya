﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_abstract_account
{
    class Saving:Account
    {
        public Saving(int accountId,string customername,int AccountBalance)
            :base(accountId,customername,AccountBalance)
        {
            Console.WriteLine("saving account constructor");
        }

        public override void deposit(int amt)
        {
            this.AccountBalance += amt + 100;  
        }

        public override void withdraw(int amt)
        {
            this.AccountBalance -= amt + 10;
        }
    }
}
