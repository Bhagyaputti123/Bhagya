﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_abstract_account
{
    abstract class Account
    {
        private int accountId;
        protected string customername;
        protected int AccountBalance;

        public Account(int accountId, string customername, int AccountBalance)
        {
            this.accountId = accountId;
            this.customername = customername;
            this.AccountBalance = AccountBalance;
            Console.WriteLine("account constructor:");
        }
        public int PaccountId
        { get { return this.accountId; } }
        public string pcustomername
        { get { return this.customername; } }
        public int pAccountBalance
        { get { return this.AccountBalance; } }

        public void stoppayment()
        {
            Console.WriteLine("stop payment called:");
        }
        public void Blockaccount()
        {
            Console.WriteLine("block account called:");
        }
        public int Getbalance()
        {
            return this.AccountBalance;
        }
        public abstract void deposit(int amt);
        public abstract void withdraw(int amt);

    } 
    
}
