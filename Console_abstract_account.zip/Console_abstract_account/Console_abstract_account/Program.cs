﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_abstract_account
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter account id:");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter customer name:");
            string name = Console.ReadLine();
            Console.WriteLine("enter account balance:");
            int bal = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the account type:");
            string type = Console.ReadLine();
            Account obj = null;
            if(type=="saving")
            {
                obj = new Saving(id, name, bal);
            }
            else if(type=="current")
            {
                obj = new Current(id, name, bal);

            }
            if(obj!=null)
            {
                obj.stoppayment();
                obj.Blockaccount();
                int Accbalance = obj.Getbalance();
                Console.WriteLine("balance:"+Accbalance);
                Console.WriteLine("enter the amount to be deposit:");
                int amt = Convert.ToInt32(Console.ReadLine());
                obj.deposit(amt);
                Accbalance = obj.Getbalance();
                Console.WriteLine("Balance:" + Accbalance);
                Console.WriteLine("enter the amount to withdraw:");
                amt = Convert.ToInt32(Console.ReadLine());
                obj.withdraw(amt);
                Accbalance = obj.Getbalance();
                Console.WriteLine("Balance:" + Accbalance);
                Console.ReadLine();


            }


        }
    }
}
