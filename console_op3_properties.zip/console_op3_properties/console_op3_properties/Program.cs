﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace console_op3_properties
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("enter student id:");
            //int stid = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter student name:");
            string name = Console.ReadLine();
            Console.WriteLine("enter marks:");
            int mar = Convert.ToInt32(Console.ReadLine());
            Student obj = new Student(name,mar);
            Student s1 = new Student("ab", 60);
            Console.WriteLine(s1.Studentid());
            int sid = obj.Studentid;
            string sname = obj.studentname;
            int smarks = obj.studentmarks;
            Console.WriteLine(sid + " "+sname);
            obj.studentmarks = 101;
            Console.WriteLine(obj.studentmarks);
            obj.studentmarks = 50;
            Console.WriteLine(obj.studentmarks);
            Console.ReadLine();

        }
    }
}
