﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace console_op3_properties
{
    class Student
    {
        private int sid;
        private string sname;
        private int marks;

        public int studentmarks
        {
            get
            {
                return this.marks;
            }
            set
            {
                if(value<0||value>100)
                {
                    this.marks = 0;
                }
                else
                {
                    this.marks = value;
                }
            }
        }
        public int Studentid
        {
            get
            {
                return sid;
            }
        }
        public string studentname
        {
            get
            {
                return sname;
            }
        }
        private static int count = 1000;
      public  Student(string sname,int marks)
        {
            Student.count++;
            this.sid = Student.count;
            this.sname = sname;
            this.marks = marks;
            Console.WriteLine("object constructor:");
        }
        public static void call()
        {

        }
        static Student()
        {
            Student count = 1000;
            Console.WriteLine("static constructor:");
        }

    }
}
