﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day1_basics_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[5];
            arr[0] = 10;
            arr[1] = 12;
            arr[2] = 13;
            arr[3] = 14;
            arr[4] = 15;
           
            for(int c=0;c<arr.Length;c++)
                {
                    
                Console.Write(c);
            }
            
            int x = 0;
            while(x<10)
            {
                Console.Write(x);
                x++;
            }
            for(int c=0;c<10;c++)
            {
                Console.Write(c);
            }
            foreach( int n in arr)
            {
                Console.WriteLine(n);
            }
            bool flag = true;
            while(flag)
            {

 Console.WriteLine(flag);
                flag = false;
            }

            int opt = 1;
            switch(opt)
            {
                case 1:
                    Console.Write("one");
                    break;
                case 2:
                    Console.Write("two");
                    break;
                case 3:
                    Console.Write("three");
                    break;
                default:
                    Console.Write("invaild");
                    break;

            }
            Console.WriteLine("enter item name\n");
           string item1= Console.ReadLine();
            Console.WriteLine("enter item quantity\n");
            int qty = Convert.ToInt32(Console.ReadLine());
            if (qty < 1)
            {
                Console.WriteLine("invalid quantity\n");
            }
            else
            {
                Console.WriteLine("valid quantity\n");
            }
            Console.ReadLine();
        }

            }
        }
    
