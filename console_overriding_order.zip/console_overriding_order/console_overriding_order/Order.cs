﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace console_overriding_order
{
    class Order
    {
        private int orderid;
        private string customername;
        private int itemqty;
        private int itemprice;
        private static int count = 1000;

        public int porderid
        { get { return this.orderid; } }
        public string pcustomername
        { get { return this.customername; } }
        public int pitemqty
        { get { return itemqty; } }
        public int pitemprice
        { get { return itemprice; } }
        
        public Order(string customername, int itemqty, int itemprice)
        {
            count++;
            this.orderid = Order.count;
            this.customername = customername;
            this.itemqty = itemqty;
            this.itemprice = itemprice;
        }
        public virtual int Getordervalue()
        {
            int total = itemqty * itemprice;
            return total;
        }
    }
}
