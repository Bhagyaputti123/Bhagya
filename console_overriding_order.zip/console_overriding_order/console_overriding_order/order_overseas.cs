﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace console_overriding_order
{
    class order_overseas:Order
    {
        public order_overseas(string customername,int itemqty,int itemprice):base(customername,itemqty,itemprice)
        {
         
        }
        public override int Getordervalue()
        {
            int total1 = (pitemqty * pitemprice)+100 ;
            return total1;
        }
    }
}
