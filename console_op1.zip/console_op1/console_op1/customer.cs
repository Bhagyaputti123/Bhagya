﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace console_op1
{
    class customer
    {
        private int custid;
        private string custname;
        private string custcity;
        public customer()
        {
        }
            public customer (int custid,string custname,string custcity)
        {
            this.custid = custid;
            this.custname = custname;
            this.custcity = custcity;

        }
        public string GetDetails()
        {
            return this.custid  + this.custname + this.custcity;

        }
        
    }
}
