﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace console_op1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter account id:");
            int accid = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter custmer name:");
            string name = Console.ReadLine();
            Console.WriteLine("enter account balance:");
            int bal = Convert.ToInt32(Console.ReadLine());
            Account obj = new Account(accid, name, bal);
            int Newbalance = obj.Getaccountbal();
            Console.WriteLine("account balance" + Newbalance);
            Console.WriteLine("enter new amount to withdraw:");
            int Amt = Convert.ToInt32(Console.ReadLine());
            obj.withdraw(Amt);
            Newbalance = obj.Getaccountbal();
            Console.WriteLine("Acoount balance:" + Newbalance);
            Console.WriteLine("enter the amount to deposit:" );
             Amt = Convert.ToInt32(Console.ReadLine());
            obj.deposit(Amt);


            /*  Console.WriteLine("enter custmer id:");
              int id = Convert.ToInt32(Console.ReadLine());
              Console.WriteLine("enter custmer name:");
              string name=Console.ReadLine();
              Console.WriteLine("enter custmer city:");
              string city= Console.ReadLine();
              customer obj = new customer();

              string deatils obj.GetDetails();*/

            Console.ReadLine();
        }
    }
}
