﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace console_op1
{
    class Account
    {
        private int accountid;
        private string custname;
        private int accountbal;

        public Account(int accountid, string custname, int accountnbal:this)
        {
            this.accountid = accountid;
            this.custname = custname;
            this.accountbal = accountbal;
            Console.WriteLine("constructor called in parameter:");
        }
        public Account()
        {
            Console.WriteLine("constructor called:");
        }
        public void withdraw(int amt)
        {
            this.accountbal = this.accountbal - amt;
        }
        public void deposit(int amt)
        {
            this.accountbal = this.accountbal + amt;
        }
        public int Getaccountbal()
        {
            return this.accountbal;
        }
        public string Getcustname()
        {
            return this.custname;
        }
    }
}

