﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_frm_calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_sum_Click(object sender, EventArgs e)
        {
            if(txt_number1.Text==string.Empty)
            {
                MessageBox.Show("enter number 1");
            }
            else if(txt_number2.Text==string.Empty)
            {
                MessageBox.Show("enter number 2");
            }
            else
            {
                int num1 = Convert.ToInt32(txt_number1.Text);
                int num2= Convert.ToInt32(txt_number2.Text);
                Calculator.Class1 obj1 = new Calculator.Class1();
                int sum = obj1.GetSum(num1, num2);
                lbl_result.Text =sum.ToString();
            }
            
            
        }

        private void btn_Multiply_Click(object sender, EventArgs e)
        {
            if (txt_number1.Text == string.Empty)
            {
                MessageBox.Show("enter number 1");
            }
            else if (txt_number2.Text == string.Empty)
            {
                MessageBox.Show("enter number 2");
            }
            else
            {
                int num1 = Convert.ToInt32(txt_number1.Text);
                int num2 = Convert.ToInt32(txt_number2.Text);
                Calculator.Class1 obj2 = new Calculator.Class1();
                int multi = obj2.GetMultiply(num1, num2);
                lbl_result.Text = multi.ToString() ;

            }
        }

        private void btn_divide_Click(object sender, EventArgs e)
        {
            if (txt_number1.Text == string.Empty)
            {
                MessageBox.Show("enter number 1");
            }
            else if (txt_number2.Text == string.Empty)
            {
                MessageBox.Show("enter number 2");
            }
            else
            {
                int num1 = Convert.ToInt32(txt_number1.Text);
                int num2 = Convert.ToInt32(txt_number2.Text);
                Calculator.Class1 obj3 = new Calculator.Class1();
                int divide = obj3.GetDivide(num1, num2);
                lbl_result.Text = divide.ToString();
            }
        }

        private void btn_sutract_Click(object sender, EventArgs e)
        {
            if (txt_number1.Text == string.Empty)
            {
                MessageBox.Show("enter number 1");
            }
            else if (txt_number2.Text == string.Empty)
            {
                MessageBox.Show("enter number 2");
            }
            else
            {
                int num1 = Convert.ToInt32(txt_number1.Text);
                int num2 = Convert.ToInt32(txt_number2.Text);
                Calculator.Class1 obj4 = new Calculator.Class1();
                int sub = obj4.GetSubtract(num1, num2);
                lbl_result.Text =sub.ToString();
            }
        }
    }
}
