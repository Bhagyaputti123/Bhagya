﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day2_task3_order
{
    class Program
      {
        static void Main(string[] args)
        {
          
            Console.WriteLine("enter customer name:");
            string name = Console.ReadLine();
            Console.WriteLine("enter item name:");
            string iname = Console.ReadLine();
            Console.WriteLine("enter item price:");
            int price = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter item quantity:");
            int qty = Convert.ToInt32(Console.ReadLine());
            Order obj = new Order(name, iname, price, qty);
            int amount = obj.GetorderAmount();
            Console.WriteLine(amount);
            Console.WriteLine(obj.porderid);
            Console.WriteLine(obj.pcustomername);
            Console.WriteLine(obj.pitemname);
            Console.WriteLine(obj.pitemprice);
            Console.WriteLine(obj.pitemquantity);

            Console.ReadLine();

        }
    }
}
