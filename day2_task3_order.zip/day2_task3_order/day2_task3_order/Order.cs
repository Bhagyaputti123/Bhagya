﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day2_task3_order
{
    class Order
    {
        private int oid;
        private string cname;
        private string iname;
        private int iprice;
        private int iqty;
        
        public int porderid
        {
            get
            {
                return oid;
            }
        }
        public string pcustomername
        {
            get
            {
                return cname;
            }
        }
        public string pitemname
        {
            get
            {
                return iname;

            }
        }
        public int pitemprice
        {
            get
            {
                return iprice;
            }
        }
        public int pitemquantity
        {
            get
            {
                return iqty;
            }
        }

        static int count = 100;
        public Order(string cname, string iname,int iprice,int iqty)
        {
            Order.count++;
            this.oid = Order.count;
            this.cname = cname;
            this.iname = iname;
            this.iprice = iprice;
            this.iqty = iqty;
        }
        public int GetorderAmount()
        {
            int total = iprice * iqty;
            return total;
        }



    }
}
