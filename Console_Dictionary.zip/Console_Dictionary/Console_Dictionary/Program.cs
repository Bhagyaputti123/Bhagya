﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Dictionary
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, string> names = new Dictionary<string, string>();
            names.Add("E1", "bhagya");
            names.Add("E2", "roja");
            names.Add("E3", "sindhu");
            names.Add("E4", "madhu");
            foreach(KeyValuePair<string,string> s in names)
            {
                Console.WriteLine(s.Key + " " + s.Value);
            }

            foreach(string k in names.Keys )
                {
                Console.WriteLine(k);

            }
            foreach(string l in names.Values)
            {
                Console.WriteLine(l);
            }
            string name = names["E1"];
            Console.WriteLine(name);
            Console.ReadLine();
        }
    }
}
