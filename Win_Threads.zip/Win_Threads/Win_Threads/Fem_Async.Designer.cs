﻿namespace Win_Threads
{
    partial class Fem_Async
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_number1 = new System.Windows.Forms.TextBox();
            this.txt_number2 = new System.Windows.Forms.TextBox();
            this.lbl_number1 = new System.Windows.Forms.Label();
            this.lbl_number2 = new System.Windows.Forms.Label();
            this.btn_asyncsum = new System.Windows.Forms.Button();
            this.lst_msg = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // txt_number1
            // 
            this.txt_number1.Location = new System.Drawing.Point(307, 70);
            this.txt_number1.Name = "txt_number1";
            this.txt_number1.Size = new System.Drawing.Size(100, 20);
            this.txt_number1.TabIndex = 6;
            // 
            // txt_number2
            // 
            this.txt_number2.Location = new System.Drawing.Point(307, 166);
            this.txt_number2.Name = "txt_number2";
            this.txt_number2.Size = new System.Drawing.Size(100, 20);
            this.txt_number2.TabIndex = 7;
            // 
            // lbl_number1
            // 
            this.lbl_number1.AutoSize = true;
            this.lbl_number1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_number1.Location = new System.Drawing.Point(99, 65);
            this.lbl_number1.Name = "lbl_number1";
            this.lbl_number1.Size = new System.Drawing.Size(98, 25);
            this.lbl_number1.TabIndex = 8;
            this.lbl_number1.Text = "Number1:";
            // 
            // lbl_number2
            // 
            this.lbl_number2.AutoSize = true;
            this.lbl_number2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_number2.Location = new System.Drawing.Point(99, 160);
            this.lbl_number2.Name = "lbl_number2";
            this.lbl_number2.Size = new System.Drawing.Size(98, 25);
            this.lbl_number2.TabIndex = 9;
            this.lbl_number2.Text = "Number2:";
            // 
            // btn_asyncsum
            // 
            this.btn_asyncsum.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_asyncsum.Location = new System.Drawing.Point(104, 297);
            this.btn_asyncsum.Name = "btn_asyncsum";
            this.btn_asyncsum.Size = new System.Drawing.Size(141, 42);
            this.btn_asyncsum.TabIndex = 10;
            this.btn_asyncsum.Text = "Async Sum";
            this.btn_asyncsum.UseVisualStyleBackColor = true;
            this.btn_asyncsum.Click += new System.EventHandler(this.btn_asyncsum_Click);
            // 
            // lst_msg
            // 
            this.lst_msg.FormattingEnabled = true;
            this.lst_msg.Location = new System.Drawing.Point(286, 297);
            this.lst_msg.Name = "lst_msg";
            this.lst_msg.Size = new System.Drawing.Size(226, 95);
            this.lst_msg.TabIndex = 11;
            // 
            // Fem_Async
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(727, 456);
            this.Controls.Add(this.lst_msg);
            this.Controls.Add(this.btn_asyncsum);
            this.Controls.Add(this.lbl_number2);
            this.Controls.Add(this.lbl_number1);
            this.Controls.Add(this.txt_number2);
            this.Controls.Add(this.txt_number1);
            this.Name = "Fem_Async";
            this.Text = "Fem_Async";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_number1;
        private System.Windows.Forms.TextBox txt_number2;
        private System.Windows.Forms.Label lbl_number1;
        private System.Windows.Forms.Label lbl_number2;
        private System.Windows.Forms.Button btn_asyncsum;
        private System.Windows.Forms.ListBox lst_msg;
    }
}