﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
namespace Win_Threads
{
    public partial class Fem_Async : Form
    {

        public delegate int dethread(int n1, int n2);


        public int GetSum(int n1,int n2)
        {
            Thread.Sleep(1000);
            return n1 + n2;
        }

        public delegate void del();
        public void callback(IAsyncResult res)
        {
            int returndata = d.EndInvoke(res);
            //MessageBox.Show("getsum called:"+res.AsyncState+":"+returndata);
            del obj = new del(() =>
                  {

                      lst_msg.Items.Add(res.AsyncState + ":" + returndata);
                  });
            this.BeginInvoke(obj);
        }


        public Fem_Async()
        {
            InitializeComponent();
        }
        dethread d;
        private void btn_asyncsum_Click(object sender, EventArgs e)
        {
            if(d==null)
            {
                d = new dethread(this.GetSum);
            }
            int n1 = Convert.ToInt32(txt_number1.Text);
            int n2 = Convert.ToInt32(txt_number2.Text);
            string str = n1 + "+" + n2;
           
            d.BeginInvoke(n1, n2, callback, str);//new thread
            //d.BeginInvoke(10, 20, callback, "1002");

        }
    }
}
