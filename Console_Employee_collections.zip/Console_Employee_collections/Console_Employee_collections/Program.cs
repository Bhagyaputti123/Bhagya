﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Employee_collections
{
    class Program
    {
        static void Main(string[] args)
        {
            Company c = new Company("TCS","Banglore");
         
            bool flag = true;
            while (flag)
            {
                Console.WriteLine("enter the choice:1-Add,2-Find,3-Remove,4-Show,5-exit,6-leave");
                int choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        Console.WriteLine("enter employee name:");
                        string name = Console.ReadLine();
                        Console.WriteLine("enter employee city:");
                        string city = Console.ReadLine();
                        Employee e1 = new Employee(name, city);
                        c.AddEmployee(e1);
                        Console.WriteLine("employee added:" + e1.PEmployeeID);
                        break;
                    case 2:
                        Console.WriteLine("Enter employee id:");
                        int ID = Convert.ToInt32(Console.ReadLine());
                        Employee obj = c.Find(ID);
                        if (obj != null)
                        {
                            Console.WriteLine(obj.PEmployeeCity + " " + obj.PEmployeeName);
                        }
                        else
                        {
                            Console.WriteLine("employee not found:");
                        }
                        break;
                    case 3:
                        Console.WriteLine("enter employee id:");
                        int EID = Convert.ToInt32(Console.ReadLine());
                        bool status = c.Remove(EID);
                        if (status)
                        {
                            Console.WriteLine("Employee removes:");

                        }
                        else
                        {
                            Console.WriteLine("employee not found:");
                        }
                        break;
                    case 4:
                        c.ShowAll();
                        break;
                    case 5:
                        flag = false;
                        break;
                    case 6:
                        Console.WriteLine("enter employee id:");
                        int emid = Convert.ToInt32(Console.ReadLine());
                        Employee eobj = c.Find(emid);
                        Console.WriteLine("enter reason:");
                        string reason = Console.ReadLine();
                        eobj.TakeLeave(reason);
                        break;


                }
            }


        }
    }
}

        
    

