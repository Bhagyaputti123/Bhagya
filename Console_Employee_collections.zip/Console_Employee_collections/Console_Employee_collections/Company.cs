﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Employee_collections
{
    class Company
    {
        public void onleave(int EID,string reason)
        {
            Console.WriteLine("Company class:employee on leave:" + EID+"," + reason);
        }


        private string CompanyName;
        private string address;
        public Company(string CompanyName,string address)
        {
            this.CompanyName = CompanyName;
            this.address = address;
        }
        private List<Employee> Employeelist = new List<Employee>();
        public void AddEmployee(Employee emp)
        {
            Employee.delleave d= new Employee.delleave(this.onleave);
            emp.evtleave += d;
            Employeelist.Add(emp);

        }
        public Employee Find(int ID)
        {
            foreach(Employee e in Employeelist)
            {
                if(e.PEmployeeID==ID)
                {
                    return e;
                }
            }
            return null;
        }
        public bool Remove(int ID)
        {
            foreach (Employee e in Employeelist)
            {
                if (e.PEmployeeID == ID)
                {
                    Employeelist.Remove(e);
                    return true;
                }
            }
            return false;
        }
        public void ShowAll()
        {
            foreach(Employee e in Employeelist)
            {
                Console.WriteLine(e.PEmployeeID + " " + e.PEmployeeName + " " + e.PEmployeeCity);
                
            }
            
        }

    }
}
