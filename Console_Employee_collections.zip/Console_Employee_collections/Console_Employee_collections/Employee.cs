﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Employee_collections
{
    class Employee
    {
        public delegate void delleave(int EID, string reason);
        public event delleave evtleave;


        private int EmployeeID;
        private string EmployeeName;
        private string EmployeeCity;
        private static int count = 1000;

        public Employee(string EmployeeName,string EmployeeCity)
        {
            Employee.count++;
            this.EmployeeID = Employee.count;
            this.EmployeeName = EmployeeName;
            this.EmployeeCity = EmployeeCity;
        }
        
        public int PEmployeeID
        { get { return this.EmployeeID; } }
        public string PEmployeeName
        { get { return this.EmployeeName; } }
        public string PEmployeeCity
        { get { return this.EmployeeCity; } }
        
        public void TakeLeave(string reason)
        {
            if(evtleave!=null)
            {
                this.evtleave(this.EmployeeID, reason);
            }
            Console.WriteLine("employee on laeve:" + this.EmployeeID + "Reason:" + reason);
        }
  

    }
}
