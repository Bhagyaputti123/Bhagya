﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_ADO_customer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lbl_cname_Click(object sender, EventArgs e)
        {
        }
        private void btn_update_Click(object sender, EventArgs e)
        {
            if (txt_cid.Text == string.Empty)
            {
                MessageBox.Show("enter id:");

            }
            else if (txt_cAddress.Text == string.Empty)
            {
                MessageBox.Show("enter address");
            }
            else if (txt_cmobileno.Text == string.Empty)
            {
                MessageBox.Show("enter mobile no");
            }
            else
            {

                int ID = Convert.ToInt32(txt_cid.Text);
                string address = txt_cAddress.Text;
                string mobileno = txt_cmobileno.Text;


                CustomerDAL dal = new CustomerDAL();
                bool status = dal.update(ID, address, mobileno);
                if (status)
                {
                    MessageBox.Show("updated");
                }
                else
                {
                    MessageBox.Show("not updated");
                }
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (txt_cid.Text == string.Empty)
            {
                MessageBox.Show("enter id");

            }
            else
            {
                int ID = Convert.ToInt32(txt_cid.Text);
                CustomerDAL dal = new CustomerDAL();
                bool status = dal.Delete(ID);
                if (status)
                {
                    MessageBox.Show("deleted");

                }
                else
                {
                    MessageBox.Show("not deleted");
                }
            }
        }

        
        private void button1_Click(object sender, EventArgs e)
        {
            if (txt_cid.Text == string.Empty)

            {
                MessageBox.Show("enter customer id:");
            }
            else
            {
                int ID = Convert.ToInt32(txt_cid.Text);
                CustomerDAL dal = new CustomerDAL();
                Customers c1 = dal.Find(ID);
                if (c1 != null)
                {
                    txt_cname.Text = c1.customername;
                    txt_cpassword.Text = c1.customerpassword;
                    txt_cCity.Text = c1.customercity;
                    txt_cAddress.Text = c1.customeraddress;
                    txt_cmobileno.Text = c1.customermobileno;
                    txt_cemailid.Text = c1.customeremailid;

                }
                else
                {
                    MessageBox.Show("not found");
                }

            }
        }






        private void btn_add_Click(object sender, EventArgs e)
        {
            if (txt_cid.Text == string.Empty)
            {
                MessageBox.Show("enter id:");
            }
            else if (txt_cname.Text == string.Empty)
            {
                MessageBox.Show("enter name:");

            }
            else if (txt_cpassword.Text == string.Empty)
            {
                MessageBox.Show("enter password:");
            }
            else if (txt_cAddress.Text == string.Empty)
            {
                MessageBox.Show("enter address");
            }
            else if (txt_cmobileno.Text == string.Empty)
            {
                MessageBox.Show("enter mobile no");
            }
            else if (txt_cemailid.Text == string.Empty)
            {
                MessageBox.Show("enter email id");
            }
            else
            {
                string name = txt_cname.Text;
                string password = txt_cpassword.Text;
                string city = txt_cCity.Text;
                string address = txt_cAddress.Text;
                string mobileno = txt_cmobileno.Text;
                string emailid = txt_cemailid.Text;

                Customers obj = new Customers();
                obj.customername = name;
                obj.customerpassword = password;
                obj.customercity = city;
                obj.customeraddress = address;
                obj.customermobileno = mobileno;
                obj.customeremailid = emailid;
                CustomerDAL dal = new CustomerDAL();
                int id = dal.Addcustomer(obj);
                MessageBox.Show("employee added:" + id);

            }
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
           
            txt_cpassword.Text = string.Empty;
            txt_cCity.Text = string.Empty;
            txt_cAddress.Text = string.Empty;
            txt_cmobileno.Text = string.Empty;
            txt_cemailid.Text = string.Empty;

        }
    }
}


