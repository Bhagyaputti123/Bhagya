﻿namespace win_ADO_customer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_cid = new System.Windows.Forms.Label();
            this.lbl_cname = new System.Windows.Forms.Label();
            this.lbl_cpassword = new System.Windows.Forms.Label();
            this.lbl_city = new System.Windows.Forms.Label();
            this.lbl_caddress = new System.Windows.Forms.Label();
            this.lbl_cmobileno = new System.Windows.Forms.Label();
            this.lbl_cemail = new System.Windows.Forms.Label();
            this.txt_cid = new System.Windows.Forms.TextBox();
            this.txt_cname = new System.Windows.Forms.TextBox();
            this.txt_cpassword = new System.Windows.Forms.TextBox();
            this.txt_cCity = new System.Windows.Forms.TextBox();
            this.txt_cAddress = new System.Windows.Forms.TextBox();
            this.txt_cemailid = new System.Windows.Forms.TextBox();
            this.txt_cmobileno = new System.Windows.Forms.TextBox();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_reset = new System.Windows.Forms.Button();
            this.btn_Find = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_cid
            // 
            this.lbl_cid.AutoSize = true;
            this.lbl_cid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cid.Location = new System.Drawing.Point(33, 28);
            this.lbl_cid.Name = "lbl_cid";
            this.lbl_cid.Size = new System.Drawing.Size(122, 25);
            this.lbl_cid.TabIndex = 0;
            this.lbl_cid.Text = "CustomerID:";
            // 
            // lbl_cname
            // 
            this.lbl_cname.AutoSize = true;
            this.lbl_cname.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cname.Location = new System.Drawing.Point(38, 82);
            this.lbl_cname.Name = "lbl_cname";
            this.lbl_cname.Size = new System.Drawing.Size(155, 25);
            this.lbl_cname.TabIndex = 1;
            this.lbl_cname.Text = "CustomerName:";
            this.lbl_cname.Click += new System.EventHandler(this.lbl_cname_Click);
            // 
            // lbl_cpassword
            // 
            this.lbl_cpassword.AutoSize = true;
            this.lbl_cpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cpassword.Location = new System.Drawing.Point(38, 129);
            this.lbl_cpassword.Name = "lbl_cpassword";
            this.lbl_cpassword.Size = new System.Drawing.Size(189, 25);
            this.lbl_cpassword.TabIndex = 2;
            this.lbl_cpassword.Text = "CustomerPassword:";
            // 
            // lbl_city
            // 
            this.lbl_city.AutoSize = true;
            this.lbl_city.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_city.Location = new System.Drawing.Point(38, 179);
            this.lbl_city.Name = "lbl_city";
            this.lbl_city.Size = new System.Drawing.Size(137, 25);
            this.lbl_city.TabIndex = 3;
            this.lbl_city.Text = "CustomerCity:";
            // 
            // lbl_caddress
            // 
            this.lbl_caddress.AutoSize = true;
            this.lbl_caddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_caddress.Location = new System.Drawing.Point(38, 233);
            this.lbl_caddress.Name = "lbl_caddress";
            this.lbl_caddress.Size = new System.Drawing.Size(176, 25);
            this.lbl_caddress.TabIndex = 4;
            this.lbl_caddress.Text = "CustomerAddress:";
            // 
            // lbl_cmobileno
            // 
            this.lbl_cmobileno.AutoSize = true;
            this.lbl_cmobileno.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cmobileno.Location = new System.Drawing.Point(43, 279);
            this.lbl_cmobileno.Name = "lbl_cmobileno";
            this.lbl_cmobileno.Size = new System.Drawing.Size(186, 25);
            this.lbl_cmobileno.TabIndex = 5;
            this.lbl_cmobileno.Text = "CustomerMobileNo:";
            // 
            // lbl_cemail
            // 
            this.lbl_cemail.AutoSize = true;
            this.lbl_cemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cemail.Location = new System.Drawing.Point(43, 324);
            this.lbl_cemail.Name = "lbl_cemail";
            this.lbl_cemail.Size = new System.Drawing.Size(170, 25);
            this.lbl_cemail.TabIndex = 6;
            this.lbl_cemail.Text = "CustomerEmailID:";
            // 
            // txt_cid
            // 
            this.txt_cid.Location = new System.Drawing.Point(261, 32);
            this.txt_cid.Name = "txt_cid";
            this.txt_cid.Size = new System.Drawing.Size(188, 20);
            this.txt_cid.TabIndex = 7;
            // 
            // txt_cname
            // 
            this.txt_cname.Location = new System.Drawing.Point(261, 86);
            this.txt_cname.Name = "txt_cname";
            this.txt_cname.Size = new System.Drawing.Size(188, 20);
            this.txt_cname.TabIndex = 8;
            // 
            // txt_cpassword
            // 
            this.txt_cpassword.Location = new System.Drawing.Point(261, 133);
            this.txt_cpassword.Name = "txt_cpassword";
            this.txt_cpassword.Size = new System.Drawing.Size(188, 20);
            this.txt_cpassword.TabIndex = 9;
            // 
            // txt_cCity
            // 
            this.txt_cCity.Location = new System.Drawing.Point(261, 183);
            this.txt_cCity.Name = "txt_cCity";
            this.txt_cCity.Size = new System.Drawing.Size(188, 20);
            this.txt_cCity.TabIndex = 10;
            // 
            // txt_cAddress
            // 
            this.txt_cAddress.Location = new System.Drawing.Point(261, 237);
            this.txt_cAddress.Name = "txt_cAddress";
            this.txt_cAddress.Size = new System.Drawing.Size(188, 20);
            this.txt_cAddress.TabIndex = 11;
            // 
            // txt_cemailid
            // 
            this.txt_cemailid.Location = new System.Drawing.Point(261, 330);
            this.txt_cemailid.Name = "txt_cemailid";
            this.txt_cemailid.Size = new System.Drawing.Size(188, 20);
            this.txt_cemailid.TabIndex = 12;
            // 
            // txt_cmobileno
            // 
            this.txt_cmobileno.Location = new System.Drawing.Point(261, 283);
            this.txt_cmobileno.Name = "txt_cmobileno";
            this.txt_cmobileno.Size = new System.Drawing.Size(188, 20);
            this.txt_cmobileno.TabIndex = 13;
            // 
            // btn_add
            // 
            this.btn_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_add.Location = new System.Drawing.Point(48, 395);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(75, 42);
            this.btn_add.TabIndex = 14;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_reset
            // 
            this.btn_reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reset.Location = new System.Drawing.Point(175, 395);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(75, 42);
            this.btn_reset.TabIndex = 15;
            this.btn_reset.Text = "Reset";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // btn_Find
            // 
            this.btn_Find.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Find.Location = new System.Drawing.Point(554, 65);
            this.btn_Find.Name = "btn_Find";
            this.btn_Find.Size = new System.Drawing.Size(75, 42);
            this.btn_Find.TabIndex = 16;
            this.btn_Find.Text = "Find";
            this.btn_Find.UseVisualStyleBackColor = true;
            this.btn_Find.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_update
            // 
            this.btn_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update.Location = new System.Drawing.Point(562, 180);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(110, 37);
            this.btn_update.TabIndex = 17;
            this.btn_update.Text = "Update";
            this.btn_update.UseVisualStyleBackColor = true;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.Location = new System.Drawing.Point(562, 283);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(110, 46);
            this.btn_delete.TabIndex = 18;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(730, 449);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.btn_Find);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.txt_cmobileno);
            this.Controls.Add(this.txt_cemailid);
            this.Controls.Add(this.txt_cAddress);
            this.Controls.Add(this.txt_cCity);
            this.Controls.Add(this.txt_cpassword);
            this.Controls.Add(this.txt_cname);
            this.Controls.Add(this.txt_cid);
            this.Controls.Add(this.lbl_cemail);
            this.Controls.Add(this.lbl_cmobileno);
            this.Controls.Add(this.lbl_caddress);
            this.Controls.Add(this.lbl_city);
            this.Controls.Add(this.lbl_cpassword);
            this.Controls.Add(this.lbl_cname);
            this.Controls.Add(this.lbl_cid);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_cid;
        private System.Windows.Forms.Label lbl_cname;
        private System.Windows.Forms.Label lbl_cpassword;
        private System.Windows.Forms.Label lbl_city;
        private System.Windows.Forms.Label lbl_caddress;
        private System.Windows.Forms.Label lbl_cmobileno;
        private System.Windows.Forms.Label lbl_cemail;
        private System.Windows.Forms.TextBox txt_cid;
        private System.Windows.Forms.TextBox txt_cname;
        private System.Windows.Forms.TextBox txt_cpassword;
        private System.Windows.Forms.TextBox txt_cCity;
        private System.Windows.Forms.TextBox txt_cAddress;
        private System.Windows.Forms.TextBox txt_cemailid;
        private System.Windows.Forms.TextBox txt_cmobileno;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.Button btn_Find;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_delete;
    }
}

