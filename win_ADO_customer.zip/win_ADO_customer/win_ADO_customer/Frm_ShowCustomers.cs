﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_ADO_customer
{
    public partial class Frm_ShowCustomers : Form
    {
        public Frm_ShowCustomers()
        {
            InitializeComponent();
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            CustomerDAL dal = new CustomerDAL();
            string city = txt_ccity.Text;
            List<Customers> list = dal.ShowCustomers(city);
            dg_customer.DataSource = list;
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_searchall_Click(object sender, EventArgs e)
        {
            CustomerDAL dal = new CustomerDAL();
            string key = txt_ccity.Text;
            List<Customers> list = dal.Searchcustomer(key);
            dg_customer.DataSource = list;

        }
    }
}
