﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
namespace win_ADO_customer
{
    class CustomerDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
         public int Addcustomer(Customers  c)
        {

            SqlCommand com_customer_insert=new SqlCommand("proc_addCustomer", con);
            com_customer_insert.Parameters.AddWithValue("@cname", c.customername);
            com_customer_insert.Parameters.AddWithValue("@cpassword", c.customerpassword);
            com_customer_insert.Parameters.AddWithValue("@ccity", c.customercity);
            com_customer_insert.Parameters.AddWithValue("@caddress", c.customeraddress);
            com_customer_insert.Parameters.AddWithValue("@cmobilno", c.customermobileno);
            com_customer_insert.Parameters.AddWithValue("@cemail", c.customeremailid);
            com_customer_insert.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;

            con.Open();
            com_customer_insert.ExecuteNonQuery();
            SqlCommand com_custid = new SqlCommand("select @@identity",con);
            int ID = Convert.ToInt32(com_custid.ExecuteScalar());
            con.Close();
            return ID;


        }
        public Customers Find(int ID)
        {
            SqlCommand com_customer_find = new SqlCommand("select * from tbl_customers where customerid=@id", con);
            com_customer_find.Parameters.AddWithValue("@id", ID);
            con.Open();
            SqlDataReader dr=com_customer_find.ExecuteReader();
            if(dr.Read())
            {
                Customers cr = new Customers();
                cr.customerid = dr.GetInt32(0);
                cr.customername = dr.GetString(1);
                cr.customerpassword = dr.GetString(2);
                cr.customercity = dr.GetString(3);
                cr.customeraddress = dr.GetString(4);
                cr.customermobileno = dr.GetString(5);
                cr.customeremailid = dr.GetString(6);
                con.Close();
                return cr;
            }
            else
            {
                return null;
            }


        }
        public bool update(int ID,string address,string mobileno)
        {
            SqlCommand com_update = new SqlCommand("update tbl_customers set customerid=@id,customeraddress=@address,customermobileNo=@mobileno",con);
            com_update.Parameters.AddWithValue("@id", ID);
            com_update.Parameters.AddWithValue("@address", address);
            com_update.Parameters.AddWithValue("@mobileno", mobileno);
            con.Open();
            int count=com_update.ExecuteNonQuery();
            con.Close();
            if(count>0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        
        public bool Delete(int ID)
        {
            SqlCommand com_delete = new SqlCommand("delete tbl_customers where customerid=@id", con);
            com_delete.Parameters.AddWithValue("@id", ID);
            con.Open();
            int count = com_delete.ExecuteNonQuery();
            if(count>0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        
        
    }
}
