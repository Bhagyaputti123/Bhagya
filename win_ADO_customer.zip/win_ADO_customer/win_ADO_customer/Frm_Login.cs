﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_ADO_customer
{
    public partial class Frm_Login : Form
    {
        public Frm_Login()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            int ID = Convert.ToInt32(txt_loginid.Text);
            string password = txt_password.Text;
            CustomerDAL dal = new CustomerDAL();
            bool status = dal.Login(ID, password);
            if(status)
            {
                MessageBox.Show("valid user");
            }
            else
            {
                MessageBox.Show("invalid user");
            }
        }
    }
}
