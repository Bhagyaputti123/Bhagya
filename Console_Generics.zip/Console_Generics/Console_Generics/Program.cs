﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Generics
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> marks = new List<int>();
            marks.Add(100);
            marks.Add(200);
            foreach(int s in marks)
                {
                Console.WriteLine(s);
            }
            List<string> name = new List<string>();
            name.Add("Bhagya");
            name.Add("dotnet");
            foreach(string n in name)
            {
                Console.WriteLine(n);
            }

            Dictionary<int, string> nameswithkey = new Dictionary<int, string>();
            nameswithkey.Add(100, "ABC");
            nameswithkey.Add(101, "XYZ");
            string s1 = nameswithkey[100];
            Console.WriteLine(s1);


            Test t = new Test();
            int x = t.GetDetails<int>(100);
            string str = t.GetDetails<string>("abc");
            Console.WriteLine(x);
            Console.WriteLine(str);
            Console.ReadLine();

        }
    }
}
