﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Console_enum_var_dynamic_using;

namespace Console_enum_var_dynamic_using1
{
    class Test
    {
      public void Makepayment(Payment_type t)
        
        {
            Console.WriteLine(t);
        }
        public static void call()
        {


        }
    }
}
