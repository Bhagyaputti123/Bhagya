﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using x=Console_enum_var_dynamic_using1;
using static Console_enum_var_dynamic_using1.Test;

    namespace Console_enum_var_dynamic_using
{
    class Program
    {
        static void Main(string[] args)
        {
            var i = 100;
            dynamic d = 100;
            d.call();
            x.Test t = new x.Test();
            t.MakePayment(Payment_type.Netbanking);
            call();
        }

    }
}
