﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_enum_var_dynamic_using
{
    enum Payment_type
    {
        COD,Cash,Card,Netbanking;
    }
}
