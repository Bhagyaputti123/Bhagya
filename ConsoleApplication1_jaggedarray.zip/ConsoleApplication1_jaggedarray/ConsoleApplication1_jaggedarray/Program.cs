﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1_jaggedarray
{
    class Program
    {
        static void Main(string[] args)
        {
            int[][] jagged = new int[3][];
            jagged[0] = new int[2];
            jagged[1] = new int[3];
            jagged[2] = new int[2];
            jagged[0][0] = 10;
            jagged[0][1] = 20;

            jagged[1][0] = 30;
            jagged[1][1] = 40;
            jagged[1][2] = 50;

            jagged[2][0] = 60;
            jagged[2][1] = 70;

            foreach(int []j in jagged)
            {
                foreach(int m in j)
                {
                    Console.WriteLine(m);
                }
            }
            for(int c=0;c<jagged.Length;c++)
                {
                for(int i=0;i<jagged[c].Length;i++)
                {
                    Console.WriteLine(jagged[c][i]);
                }
            }
            int[,] marks = new int[2, 3];
            marks[0, 0] = 10;
            marks[0, 1] = 20;
            marks[0, 2] = 30;
            marks[1, 0] = 40;
            marks[1, 1] = 50;
            marks[1, 2] = 60;
            for(int r=0;r<marks.GetLength(0);r++)
            {
                for(int c=0;c<marks.GetLength(1);c++)
                {
                    Console.WriteLine(marks[r,c]);
                }
            }
            Console.WriteLine(jagged[0][1]);
            Console.ReadLine();
        }
    }
}
