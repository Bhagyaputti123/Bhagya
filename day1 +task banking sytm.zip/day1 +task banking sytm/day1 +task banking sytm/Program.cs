﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day1__task_banking_sytm
{
    class Program
    {
        static void Main(string[] args)
        {
            int accid, accno, bal, ch = 0, n;
            string cname, acctype;
            Console.WriteLine("enter accountid\n");
            accid = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter balance\n");
            bal = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter name\n");
            cname = Console.ReadLine();
            Console.WriteLine("enter account type\n");
            acctype = Console.ReadLine();
            bool flag = true;
            while (flag)
            {
                Console.WriteLine("enter choice\n");
                 ch = Convert.ToInt32(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        Console.WriteLine("deposit");
                        int dept = Convert.ToInt32(Console.ReadLine());
                        int total = bal + dept;
                        Console.WriteLine(total);
                        break;
                    case 2:
                        Console.WriteLine("withdraw");
                        int withd = Convert.ToInt32(Console.ReadLine());
                        bal = bal - withd;
                        Console.WriteLine(bal);
                        break;
                    case 3:
                        Console.WriteLine("checkbalance");
                        Console.WriteLine(bal);
                        break;
                    default:
                      
                        flag = false;
                        break;

                }

                Console.ReadLine();

            }
        }
    }
}
