#include<stdio.h>
int main()
{
    int a[],n,i,m;
    printf("enter number of elements\n");
    scanf("%d",&n);
    printf("enter array elements\n");
    for(i=0;i<n;i++)
        scanf("%d",a[i]);
    m=a[0];
    for(i=1;i<n;i++)
    {

    if(a[i]>m)
    {
        m=a[i];

    }
    printf("%d",m);


}
