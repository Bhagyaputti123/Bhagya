﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop_Structure
{
    class Book
    {
        private int ID;
        private string Name;
        public Book(int ID, string Name)
        {
            this.ID = ID;
            this.Name = Name;
        }
        public int pID
        {
            get { return this.ID; }
        }
        public string pName
        {
            get { return this.Name; }set { this.Name = value; }
        }


    }
}
