﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop_Structure
{
    class Program
    {
        static void Main(string[] args)
        {
            Book b1 = new Book(1, "Dotnet");//stack
            Book b2 = new Book(2, "SQL");
            Console.WriteLine(b1.pName + " " + b2.pName);
            b1 = b2;
            Console.WriteLine(b1.pName + " " + b2.pName);
            b2.pName = "XYZ";
            Console.WriteLine(b1.pName + "" + b2.pName);
            Console.ReadLine();
        }

    }
}
