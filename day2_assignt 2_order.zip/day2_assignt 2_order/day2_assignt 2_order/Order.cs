﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day2_assignt_2_order
{
    class Order
    {
        private int orderid;
        private string customername;
        private string itemname;
        private int itemprice;
        private int itemqty;
        public Order(int orderid,string customername,string itemname,int itemprice,int itemqty)
        {
            this.orderid = orderid;
            this.customername = customername;
            this.itemname = itemname;
            this.itemprice = itemprice;
            this.itemqty = itemqty;

        }
        public int GetorderAmount()
        {
            int total=itemprice * itemqty;
            return total;
        }
      public string GetDetails()
        {
            return orderid+" "+ customername+" "+itemname+" "+ itemprice+" "+ itemqty;
        }
    }
}
