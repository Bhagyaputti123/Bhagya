﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Attributes
{
    [AttributeUsage(AttributeTargets.Class|AttributeTargets.Method)]
    class DeveloperAttribute:Attribute
    {
       public string developerID { get; set; }
        public string developername { get; set; }
        public DeveloperAttribute(string developerID,string developername)
        {
            this.developerID = developerID;
            this.developername = developername;
        }


    }
}
