﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Attributes
{
    [Developer("1001","John")]
    class Test
    {
        [Obsolete("not in use,use xyz")]
        [Developer("1002","David")]
        public void call()
        {
            Console.WriteLine("call function called");
        }

    }
}
