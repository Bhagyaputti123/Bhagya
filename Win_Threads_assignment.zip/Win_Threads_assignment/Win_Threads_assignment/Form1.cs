﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Threads_assignment
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        Calc c = new Calc();
        private async void btn_add_Click(object sender, EventArgs e)
        {
            double d1 = Convert.ToDouble(txt_number1.Text);
            double d2 = Convert.ToDouble(txt_number2.Text);

            var t = c.GetCalc(d1, d2, "+");
            var result = await t;
            lst_results.Items.Add(d1 + "+" + d2 + ":" + result);

        }

        private async void btn_subtract_Click(object sender, EventArgs e)
        {
            double d1 = Convert.ToDouble(txt_number1.Text);
            double d2 = Convert.ToDouble(txt_number2.Text);

            var t = c.GetCalc(d1, d2, "-");
            var result = await t;
            lst_results.Items.Add(d1 + "-" + d2 + ":" + result);


        }
    }
}
