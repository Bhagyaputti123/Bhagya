﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Lambda
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Customer> cuslist = new List<Customer>();
            cuslist.Add(new Customer { customerID = 1, customerAge = 25, customeercity = "BGL", customerName = "ABC" });
            cuslist.Add(new Customer { customerID = 2, customerAge = 22, customeercity = "XYZ", customerName = "bhagya" });
            cuslist.Add(new Customer { customerID = 3, customerAge = 26, customeercity = "pune", customerName = "roja" });
            cuslist.Add(new Customer { customerID = 4, customerAge = 27, customeercity = "kodagu", customerName = "madhu" });
            cuslist.Add(new Customer { customerID = 5, customerAge = 22, customeercity = "mumbai", customerName = "nayana" });

            List<Orders> Ordlist = new List<Orders>();
            Ordlist.Add(new Orders { OrderID = 1001, customerID = 1, ItemName = "oneplus 6", ItemPrice = 10000 });
            Ordlist.Add(new Orders { OrderID = 1002, customerID = 1, ItemName = "Tv", ItemPrice = 350 });
            Ordlist.Add(new Orders { OrderID = 1003, customerID = 2, ItemName = "oneplus6T", ItemPrice = 40000 });
            Ordlist.Add(new Orders { OrderID = 1004, customerID = 4, ItemName = "laptop", ItemPrice = 30000 });

            var data = cuslist.Where((c) => c.customeercity == "BGL");
            foreach(var x in data)
            {
                Console.WriteLine(x.customerID + " " + x.customerName);
            }

            var count = cuslist.Count((c) => c.customeercity == "BGL");
            Console.WriteLine(count);

            var obj = cuslist.FirstOrDefault((c) => c.customerID == 1);
                if(obj!=null)
            {

                Console.WriteLine(obj.customerID + " " + obj.customerName);
            }
            else
            {
                Console.WriteLine("not found");

            }

            var status = cuslist.Exists((c) => c.customerID == 1);
                Console.WriteLine(status);

            var dataprojection = cuslist.Where((c) => c.customeercity == "BGL").
            Select((s) => new { CID = s.customerID, cname = s.customerName });
            foreach(var d in dataprojection)
            {
                Console.WriteLine(d.CID + " " + d.cname);
            }

            var dataorderby = cuslist.Where((c) => c.customerAge > 20).OrderBy((o) => o.customerName).ThenByDescending((o1) => o1.customeercity);
            foreach(var d in dataorderby)
            {
                Console.WriteLine(d.customerID + " " + d.customerName + " " + d.customeercity);
            }

            var groupdata = cuslist.GroupBy((g) => g.customeercity).Select((s) => new { city = s.Key, count = s.Count(), Avg = s.Average((a) => a.customerAge) });
            foreach(var x in groupdata)
            {
                Console.WriteLine(x.city + " " + x.count + " " + x.Avg);
            }

            var joindata = cuslist.Join(Ordlist, (c) => c.customerID, (o) => o.customerID, (c, o) => new { CID = c.customerID, cname = c.customerName, OID = o.OrderID, Iname = o.ItemName, iprice = o.ItemPrice });
            foreach(var j in joindata)
            {
                Console.WriteLine(j.CID + " " + j.cname + " " + j.OID + " " + j.Iname + " " + j.iprice);
            }




            Console.ReadLine();
        }
    }
}
