﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Lambda
{
    class Customer
    {
        public int customerID { get; set; }
        public string customerName { get; set; }
        public int customerAge { get; set; }
        public string customeercity { get; set; }



    }
}
