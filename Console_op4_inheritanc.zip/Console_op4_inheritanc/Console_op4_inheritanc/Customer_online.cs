﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_op4_inheritanc
{
    class Customer_online:Customer
    {
        private string payid;
        private string deliveryaddr;

        public Customer_online
            (string custemail,string custname,string payid, string deliveryaddr):base(custemail,custname)
        {

            this.payid = payid;
            this.deliveryaddr = deliveryaddr;
            Console.WriteLine("Customer online constructor:");
        }
        public string paymentid
        {
            get
            {
                return this.payid;
            }
        }
        public string deliveryaddress
        {
            get
            {
                return this.deliveryaddr; ;
            }
        }

    }
}
