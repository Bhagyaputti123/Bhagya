﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_op4_inheritanc
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter customer email id:");
            string id = Console.ReadLine();
            Console.WriteLine("enter customer name:");
            string name = Console.ReadLine();
            Console.WriteLine("enter customer type:");
            string type = Console.ReadLine();
            if(type=="Online")
            {
                Console.WriteLine("enter payment type:");
                string paymenttype = Console.ReadLine();
                Console.WriteLine("enter deliver address:");
                string delivaddress = Console.ReadLine();
                Customer_online obj_online = new Customer_online(id, name, paymenttype, delivaddress);
                Console.WriteLine(obj_online.pcustomeremailid+" "+obj_online.pcustomername+" "+obj_online.paymentid+" "+obj_online.deliveryaddress);


            }
            else
            {
                Customer obj1 = new Customer(id, name);
                Console.WriteLine(obj1.pcustomeremailid + " " + obj1.pcustomername);
                Console.ReadLine();

            }

            Customer obj = new Customer(id, name);
            Console.WriteLine(id + " " + name);
            Console.ReadLine();
        }
    }
}
