﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_op4_inheritanc
{
    class Customer
    {
        private string custemid;
        private string cname;
        public Customer(string custemid, string cname )

        {
            this.custemid = custemid;
            this.cname = cname;
            Console.WriteLine("customer constructor:");
        }
        public string pcustomeremailid
        {
            get
            {
                return this.custemid;
            }
        }
        public string pcustomername
        {
            get
            {
                return this.cname;
            }
        }



    }

}
