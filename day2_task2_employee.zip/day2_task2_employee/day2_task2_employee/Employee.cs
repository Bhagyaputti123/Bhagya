﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day2_task2_employee
{
    class Employee
    {
        private int employeeid;
        private string employeename;
        private string employeecity;
        private double employeesalary;

        public Employee(int employeeid, string employeename, string employeecity, double employeesalary)
        {
            this.employeeid = employeeid;
            this.employeename = employeename;
            this.employeecity = employeecity;
            this.employeesalary = employeesalary;
        }
        public double GetEmployeeSalary(int days)
        {
            double total = (employeesalary/ 30)*days;
            return total;
        }
        public string GetDetails()
        {
           return  employeeid+" "+employeename+" "+employeecity+" "+employeecity+" "+employeesalary;
         
        }
    }
}
