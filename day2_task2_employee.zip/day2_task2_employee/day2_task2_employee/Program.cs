﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day2_task2_employee
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter employee id:");
            int empid = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter employee name:");
            string ename = Console.ReadLine();
            Console.WriteLine("enter employee city:");
            string ecity = Console.ReadLine();
            Console.WriteLine("enter employee salary:");
            double sal= Convert.ToInt64(Console.ReadLine());
         
            Employee obj = new Employee(empid,ename,ecity,sal);
            Console.WriteLine("enter number of days:");
            int days = Convert.ToInt32(Console.ReadLine());
            double salary=obj.GetEmployeeSalary(days);
            Console.WriteLine(salary);
            string details= obj.GetDetails();
            Console.WriteLine(details);

            Console.ReadLine();
        }
    }
}
