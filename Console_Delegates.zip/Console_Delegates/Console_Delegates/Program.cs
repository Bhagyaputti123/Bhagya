﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Delegates
{
    class Program
    {
        static void Main(string[] args)
        {


            Test obj = new Test();
            int x = 100;
            Test.del T = new Test.del(obj.call1);
            T += new Test.del(obj.call2);
            T -= new Test.del(obj.call1);
            T += new Test.del(obj.call1);
            T += delegate (string s)
              {
                  Console.WriteLine("anonymous function:" + s + " " + x);
  
              };
            T += (s) => Console.WriteLine(s);//lamda expression
            T("hello delegate");

            Console.ReadLine();




        }
    }
}
