﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_op2_calbyval_calbyref
{
   partial  class Xyz

    {
        public void GetData()
        {

        }
    }
}
