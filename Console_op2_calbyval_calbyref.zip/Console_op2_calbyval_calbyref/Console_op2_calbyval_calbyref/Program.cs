﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_op2_calbyval_calbyref
{
    class Program
    {
        static void Main(string[] args)
        {
            Xyz obj1 = new Xyz();
            obj1.call();
            obj1.GetData();
            int[] marks = new int[3];
            marks[0] = 10;
            marks[1] = 20;
            marks[2] = 30;
            Test t = new Test();
            t.callarray(10,20,30);
            int orderval = t.Getordervalue((1000));
            Console.WriteLine(orderval);
            int x = 100;
            t.call(ref x);
            Console.WriteLine(x);
            Console.ReadLine();

        }
    }
}
