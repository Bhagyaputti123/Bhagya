﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_op2_calbyval_calbyref
{
    class Test
    {
        public void call( ref int amt)
        {
            Console.WriteLine(amt);
        }
        public void callarray (params int[] marks)
        {
            foreach(int x in marks)
            {
                Console.WriteLine(x);
            }
        }
        public int Getordervalue(int itemprice,int itemqty=1)
        {
            return itemqty*itemprice;
        }
    }
}
