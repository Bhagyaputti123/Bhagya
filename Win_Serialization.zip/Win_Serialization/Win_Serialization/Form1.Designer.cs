﻿namespace Win_Serialization
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_prdoid = new System.Windows.Forms.Label();
            this.lbl_pname = new System.Windows.Forms.Label();
            this.lbl_Pprice = new System.Windows.Forms.Label();
            this.txt_prodid = new System.Windows.Forms.TextBox();
            this.txt_pname = new System.Windows.Forms.TextBox();
            this.txt_pprice = new System.Windows.Forms.TextBox();
            this.btn_serialize = new System.Windows.Forms.Button();
            this.btn_deserialize = new System.Windows.Forms.Button();
            this.btn_xmlserialize = new System.Windows.Forms.Button();
            this.btn_deserializn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_prdoid
            // 
            this.lbl_prdoid.AutoSize = true;
            this.lbl_prdoid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_prdoid.Location = new System.Drawing.Point(84, 86);
            this.lbl_prdoid.Name = "lbl_prdoid";
            this.lbl_prdoid.Size = new System.Drawing.Size(109, 25);
            this.lbl_prdoid.TabIndex = 0;
            this.lbl_prdoid.Text = "Product ID:";
            // 
            // lbl_pname
            // 
            this.lbl_pname.AutoSize = true;
            this.lbl_pname.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_pname.Location = new System.Drawing.Point(84, 158);
            this.lbl_pname.Name = "lbl_pname";
            this.lbl_pname.Size = new System.Drawing.Size(142, 25);
            this.lbl_pname.TabIndex = 1;
            this.lbl_pname.Text = "Product Name:";
            // 
            // lbl_Pprice
            // 
            this.lbl_Pprice.AutoSize = true;
            this.lbl_Pprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Pprice.Location = new System.Drawing.Point(87, 235);
            this.lbl_Pprice.Name = "lbl_Pprice";
            this.lbl_Pprice.Size = new System.Drawing.Size(132, 25);
            this.lbl_Pprice.TabIndex = 2;
            this.lbl_Pprice.Text = "Product price:";
            // 
            // txt_prodid
            // 
            this.txt_prodid.Location = new System.Drawing.Point(266, 86);
            this.txt_prodid.Name = "txt_prodid";
            this.txt_prodid.Size = new System.Drawing.Size(170, 20);
            this.txt_prodid.TabIndex = 3;
            // 
            // txt_pname
            // 
            this.txt_pname.Location = new System.Drawing.Point(266, 155);
            this.txt_pname.Name = "txt_pname";
            this.txt_pname.Size = new System.Drawing.Size(170, 20);
            this.txt_pname.TabIndex = 4;
            // 
            // txt_pprice
            // 
            this.txt_pprice.Location = new System.Drawing.Point(266, 235);
            this.txt_pprice.Name = "txt_pprice";
            this.txt_pprice.Size = new System.Drawing.Size(170, 20);
            this.txt_pprice.TabIndex = 5;
            // 
            // btn_serialize
            // 
            this.btn_serialize.Location = new System.Drawing.Point(92, 321);
            this.btn_serialize.Name = "btn_serialize";
            this.btn_serialize.Size = new System.Drawing.Size(75, 23);
            this.btn_serialize.TabIndex = 6;
            this.btn_serialize.Text = "Serialize";
            this.btn_serialize.UseVisualStyleBackColor = true;
            this.btn_serialize.Click += new System.EventHandler(this.btn_serialize_Click);
            // 
            // btn_deserialize
            // 
            this.btn_deserialize.Location = new System.Drawing.Point(304, 321);
            this.btn_deserialize.Name = "btn_deserialize";
            this.btn_deserialize.Size = new System.Drawing.Size(75, 23);
            this.btn_deserialize.TabIndex = 7;
            this.btn_deserialize.Text = "Deserialize";
            this.btn_deserialize.UseVisualStyleBackColor = true;
            this.btn_deserialize.Click += new System.EventHandler(this.btn_deserialize_Click);
            // 
            // btn_xmlserialize
            // 
            this.btn_xmlserialize.Location = new System.Drawing.Point(92, 395);
            this.btn_xmlserialize.Name = "btn_xmlserialize";
            this.btn_xmlserialize.Size = new System.Drawing.Size(134, 23);
            this.btn_xmlserialize.TabIndex = 8;
            this.btn_xmlserialize.Text = "XML Serialize";
            this.btn_xmlserialize.UseVisualStyleBackColor = true;
            this.btn_xmlserialize.Click += new System.EventHandler(this.btn_xmlserialize_Click);
            // 
            // btn_deserializn
            // 
            this.btn_deserializn.Location = new System.Drawing.Point(304, 395);
            this.btn_deserializn.Name = "btn_deserializn";
            this.btn_deserializn.Size = new System.Drawing.Size(145, 23);
            this.btn_deserializn.TabIndex = 9;
            this.btn_deserializn.Text = "XML Deserialize";
            this.btn_deserializn.UseVisualStyleBackColor = true;
            this.btn_deserializn.Click += new System.EventHandler(this.btn_deserializn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(790, 457);
            this.Controls.Add(this.btn_deserializn);
            this.Controls.Add(this.btn_xmlserialize);
            this.Controls.Add(this.btn_deserialize);
            this.Controls.Add(this.btn_serialize);
            this.Controls.Add(this.txt_pprice);
            this.Controls.Add(this.txt_pname);
            this.Controls.Add(this.txt_prodid);
            this.Controls.Add(this.lbl_Pprice);
            this.Controls.Add(this.lbl_pname);
            this.Controls.Add(this.lbl_prdoid);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_prdoid;
        private System.Windows.Forms.Label lbl_pname;
        private System.Windows.Forms.Label lbl_Pprice;
        private System.Windows.Forms.TextBox txt_prodid;
        private System.Windows.Forms.TextBox txt_pname;
        private System.Windows.Forms.TextBox txt_pprice;
        private System.Windows.Forms.Button btn_serialize;
        private System.Windows.Forms.Button btn_deserialize;
        private System.Windows.Forms.Button btn_xmlserialize;
        private System.Windows.Forms.Button btn_deserializn;
    }
}

