﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_Serialization
{
    [Serializable]//Attribute like metadata
   public class Product
    {
        public int productid { get; set; }
        public string productname { get; set; }
        public int productprice { get; set; }



    }
}
