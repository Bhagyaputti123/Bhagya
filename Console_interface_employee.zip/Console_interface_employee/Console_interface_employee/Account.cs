﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_interface_employee
{
    class Account
    {
        public void GetEmployee(IAccountEmp obj)
        {
            int m = obj.GetEmployeesalary();
            int accno = obj.GetEmployeeaccNo();
            int id = obj.GetEmployeeID();
            Console.WriteLine("salary:" + m);
            Console.WriteLine("accno:" + accno);
            Console.WriteLine("id:" + id);
        }
    }
}
