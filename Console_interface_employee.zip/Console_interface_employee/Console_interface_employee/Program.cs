﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_interface_employee
{
    class Program
    {
        static void Main(string[] args)
        {
          
            Employee e = new Employee(1, "bhagya", "banglore", 20000, "tumkur", "dotnet", 200, 1256587768, "sbi", 21);
            HR obj1 = new HR();
            obj1.GetEmployee(e);
            Account obj2 = new Account();
            obj2.GetEmployee(e);
            Manager obj3 = new Manager();
            obj3.getEmployee(e);


            Console.ReadLine();
        }
    }
}
