﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_interface_employee
{
    interface IHREmp
    {
         string GetEmployeeaddress();
         int GetEmployeeSalary();
         int GetEmployeeID();
    }
}
