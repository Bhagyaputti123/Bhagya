﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_interface_employee
{
    interface IManagerEmployee
    {
         int GetEmployeeID();
         int GetEmployeeExp();
        string GetEmployeeprojectdetails();
    }
}
