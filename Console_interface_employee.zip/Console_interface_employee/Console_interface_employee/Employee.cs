﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_interface_employee
{
    class Employee:IHREmp,IAccountEmp,IManagerEmployee
    {
        private int EmployeeID;
        private string Employeename;
        private string Employeecity;
        private int Employeesalary;
        private string Employeeaddress;
        private string EmpprojectDetails;
        private int Employeeexp;
        private int EmpAccountNo;
        private string EmpAccBankName;
        private int EmployeeAge;

        public Employee(int EmployeeID, string Employeename, string Employeecity,
            int Employeesalary, string Employeeaddress, string EmpprojectDetails, int Employeeexp, int EmpAccountNo, string EmpAccBankName, int EmployeeAge)
        {
            this.EmployeeID = EmployeeID;
            this.Employeename = Employeename;
            this.Employeecity = Employeecity;
            this.Employeesalary = Employeesalary;
            this.Employeeaddress = Employeeaddress;
            this.EmpprojectDetails = EmpprojectDetails;
            this.Employeeexp = Employeeexp;
            this.EmpAccountNo = EmpAccountNo;
            this.EmpAccBankName = EmpAccBankName;
            this.EmployeeAge = EmployeeAge;
        }

        public string GetEmployeeaddress()
        {

            return this.Employeeaddress;
          
        }

        public int GetEmployeeSalary()
        {
            return this.Employeesalary;
        }

        public int GetEmployeeID()
        {
            return this.EmployeeID;

        }

        public int GetEmployeesalary()
        {
            return this.Employeesalary;
        }

        public int GetEmployeeaccNo()
        {
            return this.EmpAccountNo;

        }

        public int GetEmployeeExp()
        {
            return this.Employeeexp;
        }

        public string GetEmployeeprojectdetails()
        {
            return this.EmpprojectDetails;
        }
    

    }
}
