﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_interface_employee
{
    class Manager
    {
        public void getEmployee(IManagerEmployee obj)
        {
            int id = obj.GetEmployeeID();
            int exp = obj.GetEmployeeExp();
            string project = obj.GetEmployeeprojectdetails();
            Console.WriteLine("empid:" + id);
            Console.WriteLine("empexp:" + exp);
            Console.WriteLine("details:" + project);
        }
    }
}
