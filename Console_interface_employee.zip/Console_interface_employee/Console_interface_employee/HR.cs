﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_interface_employee
{
    class HR
    {
        public void GetEmployee(IHREmp obj)
        {
            string s = obj.GetEmployeeaddress();
            int i = obj.GetEmployeeSalary();
            int j = obj.GetEmployeeID();
            Console.WriteLine("employee address:" + s);
            Console.WriteLine("employee salary:" + i);
            Console.WriteLine("Employee id:" + j);

        }
    }
}
