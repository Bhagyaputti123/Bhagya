﻿namespace Login_cum_NewCustomer_Form
{
    partial class MyTransaction_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_accountid = new System.Windows.Forms.Label();
            this.btn_show = new System.Windows.Forms.Button();
            this.dg_myTransaction = new System.Windows.Forms.DataGridView();
            this.combo_accountid = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dg_myTransaction)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_accountid
            // 
            this.lbl_accountid.AutoSize = true;
            this.lbl_accountid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_accountid.Location = new System.Drawing.Point(77, 93);
            this.lbl_accountid.Name = "lbl_accountid";
            this.lbl_accountid.Size = new System.Drawing.Size(114, 25);
            this.lbl_accountid.TabIndex = 0;
            this.lbl_accountid.Text = "Account ID:";
            // 
            // btn_show
            // 
            this.btn_show.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_show.Location = new System.Drawing.Point(199, 177);
            this.btn_show.Name = "btn_show";
            this.btn_show.Size = new System.Drawing.Size(75, 40);
            this.btn_show.TabIndex = 2;
            this.btn_show.Text = "Show";
            this.btn_show.UseVisualStyleBackColor = true;
            this.btn_show.Click += new System.EventHandler(this.btn_show_Click);
            // 
            // dg_myTransaction
            // 
            this.dg_myTransaction.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_myTransaction.Location = new System.Drawing.Point(24, 244);
            this.dg_myTransaction.Name = "dg_myTransaction";
            this.dg_myTransaction.Size = new System.Drawing.Size(493, 168);
            this.dg_myTransaction.TabIndex = 3;
            // 
            // combo_accountid
            // 
            this.combo_accountid.FormattingEnabled = true;
            this.combo_accountid.Location = new System.Drawing.Point(268, 96);
            this.combo_accountid.Name = "combo_accountid";
            this.combo_accountid.Size = new System.Drawing.Size(158, 21);
            this.combo_accountid.TabIndex = 4;
            // 
            // MyTransaction_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(529, 424);
            this.Controls.Add(this.combo_accountid);
            this.Controls.Add(this.dg_myTransaction);
            this.Controls.Add(this.btn_show);
            this.Controls.Add(this.lbl_accountid);
            this.Name = "MyTransaction_Form";
            this.Text = "MyTransaction_Form";
            this.Load += new System.EventHandler(this.MyTransaction_Form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dg_myTransaction)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_accountid;
        private System.Windows.Forms.Button btn_show;
        private System.Windows.Forms.DataGridView dg_myTransaction;
        private System.Windows.Forms.ComboBox combo_accountid;
    }
}