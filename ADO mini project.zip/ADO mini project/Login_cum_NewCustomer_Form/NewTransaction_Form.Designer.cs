﻿namespace Login_cum_NewCustomer_Form
{
    partial class NewTransaction_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_accid = new System.Windows.Forms.Label();
            this.lbl_amunt = new System.Windows.Forms.Label();
            this.lbl_transtype = new System.Windows.Forms.Label();
            this.lbl_transdate = new System.Windows.Forms.Label();
            this.txt_amount = new System.Windows.Forms.TextBox();
            this.txt_transactiondate = new System.Windows.Forms.TextBox();
            this.btn_newtrans = new System.Windows.Forms.Button();
            this.combo_transactiontype = new System.Windows.Forms.ComboBox();
            this.combo_accountid = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lbl_accid
            // 
            this.lbl_accid.AutoSize = true;
            this.lbl_accid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_accid.Location = new System.Drawing.Point(90, 80);
            this.lbl_accid.Name = "lbl_accid";
            this.lbl_accid.Size = new System.Drawing.Size(114, 25);
            this.lbl_accid.TabIndex = 0;
            this.lbl_accid.Text = "Account ID:";
            // 
            // lbl_amunt
            // 
            this.lbl_amunt.AutoSize = true;
            this.lbl_amunt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_amunt.Location = new System.Drawing.Point(90, 147);
            this.lbl_amunt.Name = "lbl_amunt";
            this.lbl_amunt.Size = new System.Drawing.Size(86, 25);
            this.lbl_amunt.TabIndex = 1;
            this.lbl_amunt.Text = "Amount:";
            // 
            // lbl_transtype
            // 
            this.lbl_transtype.AutoSize = true;
            this.lbl_transtype.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_transtype.Location = new System.Drawing.Point(90, 216);
            this.lbl_transtype.Name = "lbl_transtype";
            this.lbl_transtype.Size = new System.Drawing.Size(171, 25);
            this.lbl_transtype.TabIndex = 2;
            this.lbl_transtype.Text = "Transaction Type:";
            // 
            // lbl_transdate
            // 
            this.lbl_transdate.AutoSize = true;
            this.lbl_transdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_transdate.Location = new System.Drawing.Point(90, 285);
            this.lbl_transdate.Name = "lbl_transdate";
            this.lbl_transdate.Size = new System.Drawing.Size(167, 25);
            this.lbl_transdate.TabIndex = 3;
            this.lbl_transdate.Text = "Transaction Date:";
            // 
            // txt_amount
            // 
            this.txt_amount.Location = new System.Drawing.Point(304, 152);
            this.txt_amount.Name = "txt_amount";
            this.txt_amount.Size = new System.Drawing.Size(245, 20);
            this.txt_amount.TabIndex = 5;
            // 
            // txt_transactiondate
            // 
            this.txt_transactiondate.Location = new System.Drawing.Point(304, 285);
            this.txt_transactiondate.Name = "txt_transactiondate";
            this.txt_transactiondate.Size = new System.Drawing.Size(245, 20);
            this.txt_transactiondate.TabIndex = 7;
            // 
            // btn_newtrans
            // 
            this.btn_newtrans.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newtrans.Location = new System.Drawing.Point(180, 374);
            this.btn_newtrans.Name = "btn_newtrans";
            this.btn_newtrans.Size = new System.Drawing.Size(260, 49);
            this.btn_newtrans.TabIndex = 8;
            this.btn_newtrans.Text = "NewTransaction Details";
            this.btn_newtrans.UseVisualStyleBackColor = true;
            this.btn_newtrans.Click += new System.EventHandler(this.btn_newtrans_Click);
            // 
            // combo_transactiontype
            // 
            this.combo_transactiontype.FormattingEnabled = true;
            this.combo_transactiontype.Location = new System.Drawing.Point(304, 222);
            this.combo_transactiontype.Name = "combo_transactiontype";
            this.combo_transactiontype.Size = new System.Drawing.Size(245, 21);
            this.combo_transactiontype.TabIndex = 9;
            this.combo_transactiontype.SelectedIndexChanged += new System.EventHandler(this.combo_transactiontype_SelectedIndexChanged);
            // 
            // combo_accountid
            // 
            this.combo_accountid.FormattingEnabled = true;
            this.combo_accountid.Location = new System.Drawing.Point(304, 83);
            this.combo_accountid.Name = "combo_accountid";
            this.combo_accountid.Size = new System.Drawing.Size(245, 21);
            this.combo_accountid.TabIndex = 10;
            this.combo_accountid.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // NewTransaction_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(641, 450);
            this.Controls.Add(this.combo_accountid);
            this.Controls.Add(this.combo_transactiontype);
            this.Controls.Add(this.btn_newtrans);
            this.Controls.Add(this.txt_transactiondate);
            this.Controls.Add(this.txt_amount);
            this.Controls.Add(this.lbl_transdate);
            this.Controls.Add(this.lbl_transtype);
            this.Controls.Add(this.lbl_amunt);
            this.Controls.Add(this.lbl_accid);
            this.Name = "NewTransaction_Form";
            this.Text = "NewTransaction_Form";
            this.Load += new System.EventHandler(this.NewTransaction_Form_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_accid;
        private System.Windows.Forms.Label lbl_amunt;
        private System.Windows.Forms.Label lbl_transtype;
        private System.Windows.Forms.Label lbl_transdate;
        private System.Windows.Forms.TextBox txt_amount;
        private System.Windows.Forms.TextBox txt_transactiondate;
        private System.Windows.Forms.Button btn_newtrans;
        private System.Windows.Forms.ComboBox combo_transactiontype;
        private System.Windows.Forms.ComboBox combo_accountid;
    }
}