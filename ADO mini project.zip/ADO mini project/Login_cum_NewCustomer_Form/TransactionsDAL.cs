﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
namespace Login_cum_NewCustomer_Form
{
    class TransactionsDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public int addTransaction(Transaction trans)
        {
            SqlCommand com_tran_insert = new SqlCommand("proc_addTransaction", con);
            com_tran_insert.Parameters.AddWithValue("@accid", trans.accountid);
            com_tran_insert.Parameters.AddWithValue("@amount", trans.amount);
            com_tran_insert.Parameters.AddWithValue("@transType",trans.transactiontype);
            com_tran_insert.Parameters.AddWithValue("@transDate", trans.transactiondate);
            
            
                com_tran_insert.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_tran_insert.Parameters.Add(retdata);
                con.Open();
                com_tran_insert.ExecuteNonQuery();
                con.Close();
                int TID = Convert.ToInt32(retdata.Value);
                return TID;
            
         }



        public List<Transaction> showTransaction(int id)
        {
            SqlCommand com_transaction = new SqlCommand("proc_showTransaction", con);
            com_transaction.Parameters.AddWithValue("@ID", id);
            com_transaction.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_transaction.ExecuteReader();
            List<Transaction> translist = new List<Transaction>();
            while (dr.Read())
            {
                Transaction obj = new Transaction();
                obj.transactionid = dr.GetInt32(0);
                obj.accountid = dr.GetInt32(1);
                obj.amount = dr.GetInt32(2);
                obj.transactiontype = dr.GetString(3);
                obj.transactiondate = dr.GetDateTime(4);
                translist.Add(obj);
            }
            con.Close();
            return translist;
        }

     }
}
