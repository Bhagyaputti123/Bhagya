﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Login_cum_NewCustomer_Form
{
    class Transaction
    {
        public int transactionid { get; set; }
        public int accountid { get; set; }
        public int amount { get; set; }
        public string transactiontype { get; set; }
        public DateTime transactiondate { get; set; }







    }
}
