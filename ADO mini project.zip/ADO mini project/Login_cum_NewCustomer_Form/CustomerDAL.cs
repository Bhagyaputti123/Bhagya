﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
namespace Login_cum_NewCustomer_Form
{
    class CustomerDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public int Addcustomer(Custmer cust)
        {
            try
            {
                SqlCommand com_cust_insert = new SqlCommand("proc_addCustomer", con);
                com_cust_insert.Parameters.AddWithValue("@name", cust.customername);
                com_cust_insert.Parameters.AddWithValue("@email", cust.customeremail);
                com_cust_insert.Parameters.AddWithValue("@mobileno", cust.customermobileno);
                com_cust_insert.Parameters.AddWithValue("@gender", cust.customergender);
                com_cust_insert.Parameters.AddWithValue("@password", cust.customerpassword);
                com_cust_insert.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_cust_insert.Parameters.Add(retdata);
                con.Open();
                com_cust_insert.ExecuteNonQuery();
                con.Close();
                int CID = Convert.ToInt32(retdata.Value);
                return CID;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public List<Custmer>showCustomer(string email )
        {
            try
            {
                SqlCommand com_customer = new SqlCommand("proc_showCustomer", con);
                com_customer.Parameters.AddWithValue("@email", email);
                com_customer.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader dr = com_customer.ExecuteReader();
                List<Custmer> cuslist = new List<Custmer>();
                while (dr.Read())
                {
                    Custmer obj = new Custmer();
                    obj.customerid = dr.GetInt32(0);
                    obj.customername = dr.GetString(1);
                    obj.customeremail = dr.GetString(2);
                    obj.customermobileno = dr.GetString(3);
                    obj.customergender = dr.GetString(4);
                    obj.customerpassword = dr.GetString(5);
                    cuslist.Add(obj);
                }
                con.Close();
                return cuslist;
            }
            finally
            { 
            if(con.State==ConnectionState.Open)
                {
                    con.Close();
                }
                

            }
        }
        public bool Login(int ID, string Password)
        {

            try
            {
                SqlCommand com_login = new SqlCommand("proc_login", con);
                com_login.Parameters.AddWithValue("@id", ID);
                com_login.Parameters.AddWithValue("@password", Password);
                com_login.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_login.Parameters.Add(retdata);
                con.Open();
                com_login.ExecuteNonQuery();
                con.Close();
                int count = Convert.ToInt32(retdata.Value);
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

    }
}
