﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
namespace Login_cum_NewCustomer_Form
{
    class AccountsDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public int addAccount(Account Acc)
        {
            
            SqlCommand com_acc_insert = new SqlCommand("proc_addAccount", con);
            com_acc_insert.Parameters.AddWithValue("@cid", Acc.customerid);
            com_acc_insert.Parameters.AddWithValue("@accbal", Acc.accountbalance);
            com_acc_insert.Parameters.AddWithValue("@acctype", Acc.accounttype);
            com_acc_insert.Parameters.AddWithValue("@accopendate", Acc.accountopeningdate);
           
            com_acc_insert.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_acc_insert.Parameters.Add(retdata);
            con.Open();
            com_acc_insert.ExecuteNonQuery();
            con.Close();
            int AID = Convert.ToInt32(retdata.Value);
            return AID;
        }

        public List<Account> showAccount(int id)
        {
            SqlCommand com_account = new SqlCommand("proc_showAccount", con);
            com_account.Parameters.AddWithValue("@ID", id);
            com_account.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_account.ExecuteReader();
            List<Account> acclist = new List<Account>();
            while (dr.Read())
            {
                Account obj = new Account();
                obj.accountid = dr.GetInt32(0);
                obj.customerid = dr.GetInt32(1);
                obj.accountbalance = dr.GetInt32(2);
                obj.accounttype = dr.GetString(3);
                obj.accountopeningdate = dr.GetDateTime(4);
                acclist.Add(obj);
            }
            con.Close();
            return acclist;
        }

        public List<int> accounts(int id)
        {
            SqlCommand com_acc = new SqlCommand("proc_acid", con);
            com_acc.Parameters.AddWithValue("@id", id);
            com_acc.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader sdr = com_acc.ExecuteReader();
            List<int> acclist = new List<int>();
            while(sdr.Read())
            {
                int aid = sdr.GetInt32(0);
                acclist.Add(aid);
            }
            con.Close();
            return acclist;
            
        } 
        public int accBalance(int id)
        {
            SqlCommand com_acc_insert = new SqlCommand("proc_transntype", con);
            com_acc_insert.Parameters.AddWithValue("@id", id);
            com_acc_insert.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_acc_insert.Parameters.Add(retdata);
            con.Open();
            com_acc_insert.ExecuteNonQuery();
            con.Close();
            int AID = Convert.ToInt32(retdata.Value);
            return AID;
        }

    }

}

