﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Login_cum_NewCustomer_Form
{
    class Custmer
    {

        public int customerid { get; set; }
        public string customername { get; set; }
        public string customeremail { get; set; }
        public string customermobileno { get; set; }
        public string customergender { get; set; }
        public string customerpassword { get; set; }






    }
}
