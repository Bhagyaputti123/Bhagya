﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Login_cum_NewCustomer_Form
{
    class Test
    {
        public static int customerid;
        
       

    }
}
