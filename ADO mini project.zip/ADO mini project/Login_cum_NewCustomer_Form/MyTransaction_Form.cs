﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login_cum_NewCustomer_Form
{
    public partial class MyTransaction_Form : Form
    {
        public MyTransaction_Form()
        {
            InitializeComponent();
        }

        private void btn_show_Click(object sender, EventArgs e)
        {
            TransactionsDAL dal = new TransactionsDAL();
            int id = Convert.ToInt32(combo_accountid.Text);
            List<Transaction> list = dal.showTransaction(id);
            dg_myTransaction.DataSource = list;

        }

        private void MyTransaction_Form_Load(object sender, EventArgs e)
        {
            AccountsDAL dal = new AccountsDAL();
            List<int> list = dal.accounts(Test.customerid);
            foreach(var k in list)
            {
                combo_accountid.Items.Add(k);
            }
        }
    }
}
