﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login_cum_NewCustomer_Form
{
    public partial class Home_Form : Form
    {
        public Home_Form()
        {
            InitializeComponent();
        }

        private void btn_newaccount_Click(object sender, EventArgs e)
        {
            NewAccount_Form frm1 = new NewAccount_Form();
            frm1.Show();
        }

        private void btn_newtransaction_Click(object sender, EventArgs e)
        {
            NewTransaction_Form frm2 = new NewTransaction_Form();
            frm2.Show();
        }

        private void btn_myaccount_Click(object sender, EventArgs e)
        {
            MyAccounts_Form frm3 = new MyAccounts_Form();
            frm3.Show();
        }

        private void btn_mytransaction_Click(object sender, EventArgs e)
        {
            MyTransaction_Form frm4 = new MyTransaction_Form();
            frm4.Show();
        }
    }
}
