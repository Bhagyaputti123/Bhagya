﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login_cum_NewCustomer_Form
{
    public partial class MyAccounts_Form : Form
    {
        public MyAccounts_Form()
        {
            InitializeComponent();
        }

        private void btn_show_Click(object sender, EventArgs e)
        {
            AccountsDAL dal = new AccountsDAL();
            int id = Convert.ToInt32(txt_customerid.Text);
            List<Account> acclist = dal.showAccount(id);
            dg_myaccount.DataSource = acclist;
        }

        private void dg_myaccount_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
