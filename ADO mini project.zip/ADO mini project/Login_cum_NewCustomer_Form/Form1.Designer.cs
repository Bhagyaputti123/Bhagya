﻿namespace Login_cum_NewCustomer_Form
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_login = new System.Windows.Forms.Label();
            this.lbl_password = new System.Windows.Forms.Label();
            this.txt_loginid = new System.Windows.Forms.TextBox();
            this.txt_password = new System.Windows.Forms.TextBox();
            this.btn_login = new System.Windows.Forms.Button();
            this.btn_reset = new System.Windows.Forms.Button();
            this.lbl_cname = new System.Windows.Forms.Label();
            this.lbl_cemail = new System.Windows.Forms.Label();
            this.lbl_cmobileno = new System.Windows.Forms.Label();
            this.lbl_cgender = new System.Windows.Forms.Label();
            this.lbl_cpassword = new System.Windows.Forms.Label();
            this.txt_cname = new System.Windows.Forms.TextBox();
            this.txt_cemailid = new System.Windows.Forms.TextBox();
            this.txt_cmobileno = new System.Windows.Forms.TextBox();
            this.txt_cgender = new System.Windows.Forms.TextBox();
            this.txt_cpassword = new System.Windows.Forms.TextBox();
            this.btn_new = new System.Windows.Forms.Button();
            this.btn_reset2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_login
            // 
            this.lbl_login.AutoSize = true;
            this.lbl_login.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_login.Location = new System.Drawing.Point(56, 66);
            this.lbl_login.Name = "lbl_login";
            this.lbl_login.Size = new System.Drawing.Size(136, 25);
            this.lbl_login.TabIndex = 0;
            this.lbl_login.Text = "Enter LoginID:";
            // 
            // lbl_password
            // 
            this.lbl_password.AutoSize = true;
            this.lbl_password.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_password.Location = new System.Drawing.Point(56, 117);
            this.lbl_password.Name = "lbl_password";
            this.lbl_password.Size = new System.Drawing.Size(104, 25);
            this.lbl_password.TabIndex = 1;
            this.lbl_password.Text = "Password:";
            // 
            // txt_loginid
            // 
            this.txt_loginid.Location = new System.Drawing.Point(198, 71);
            this.txt_loginid.Name = "txt_loginid";
            this.txt_loginid.Size = new System.Drawing.Size(147, 20);
            this.txt_loginid.TabIndex = 2;
            // 
            // txt_password
            // 
            this.txt_password.Location = new System.Drawing.Point(198, 117);
            this.txt_password.Name = "txt_password";
            this.txt_password.Size = new System.Drawing.Size(147, 20);
            this.txt_password.TabIndex = 3;
            // 
            // btn_login
            // 
            this.btn_login.BackColor = System.Drawing.SystemColors.Highlight;
            this.btn_login.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_login.Location = new System.Drawing.Point(64, 184);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(104, 47);
            this.btn_login.TabIndex = 4;
            this.btn_login.Text = "Login";
            this.btn_login.UseVisualStyleBackColor = false;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // btn_reset
            // 
            this.btn_reset.BackColor = System.Drawing.SystemColors.Highlight;
            this.btn_reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reset.Location = new System.Drawing.Point(231, 184);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(75, 47);
            this.btn_reset.TabIndex = 5;
            this.btn_reset.Text = "Reset";
            this.btn_reset.UseVisualStyleBackColor = false;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // lbl_cname
            // 
            this.lbl_cname.AutoSize = true;
            this.lbl_cname.Location = new System.Drawing.Point(519, 74);
            this.lbl_cname.Name = "lbl_cname";
            this.lbl_cname.Size = new System.Drawing.Size(85, 13);
            this.lbl_cname.TabIndex = 6;
            this.lbl_cname.Text = "Customer Name:";
            // 
            // lbl_cemail
            // 
            this.lbl_cemail.AutoSize = true;
            this.lbl_cemail.Location = new System.Drawing.Point(519, 117);
            this.lbl_cemail.Name = "lbl_cemail";
            this.lbl_cemail.Size = new System.Drawing.Size(93, 13);
            this.lbl_cemail.TabIndex = 7;
            this.lbl_cemail.Text = "Customer EmailID:";
            // 
            // lbl_cmobileno
            // 
            this.lbl_cmobileno.AutoSize = true;
            this.lbl_cmobileno.Location = new System.Drawing.Point(519, 164);
            this.lbl_cmobileno.Name = "lbl_cmobileno";
            this.lbl_cmobileno.Size = new System.Drawing.Size(102, 13);
            this.lbl_cmobileno.TabIndex = 8;
            this.lbl_cmobileno.Text = "Customer MobileNo:";
            // 
            // lbl_cgender
            // 
            this.lbl_cgender.AutoSize = true;
            this.lbl_cgender.Location = new System.Drawing.Point(519, 204);
            this.lbl_cgender.Name = "lbl_cgender";
            this.lbl_cgender.Size = new System.Drawing.Size(92, 13);
            this.lbl_cgender.TabIndex = 9;
            this.lbl_cgender.Text = "Customer Gender:";
            // 
            // lbl_cpassword
            // 
            this.lbl_cpassword.AutoSize = true;
            this.lbl_cpassword.Location = new System.Drawing.Point(518, 247);
            this.lbl_cpassword.Name = "lbl_cpassword";
            this.lbl_cpassword.Size = new System.Drawing.Size(103, 13);
            this.lbl_cpassword.TabIndex = 10;
            this.lbl_cpassword.Text = "Customer Password:";
            // 
            // txt_cname
            // 
            this.txt_cname.Location = new System.Drawing.Point(659, 71);
            this.txt_cname.Name = "txt_cname";
            this.txt_cname.Size = new System.Drawing.Size(174, 20);
            this.txt_cname.TabIndex = 11;
            // 
            // txt_cemailid
            // 
            this.txt_cemailid.Location = new System.Drawing.Point(659, 114);
            this.txt_cemailid.Name = "txt_cemailid";
            this.txt_cemailid.Size = new System.Drawing.Size(174, 20);
            this.txt_cemailid.TabIndex = 12;
            // 
            // txt_cmobileno
            // 
            this.txt_cmobileno.Location = new System.Drawing.Point(659, 161);
            this.txt_cmobileno.Name = "txt_cmobileno";
            this.txt_cmobileno.Size = new System.Drawing.Size(174, 20);
            this.txt_cmobileno.TabIndex = 13;
            // 
            // txt_cgender
            // 
            this.txt_cgender.Location = new System.Drawing.Point(659, 197);
            this.txt_cgender.Name = "txt_cgender";
            this.txt_cgender.Size = new System.Drawing.Size(174, 20);
            this.txt_cgender.TabIndex = 14;
            // 
            // txt_cpassword
            // 
            this.txt_cpassword.Location = new System.Drawing.Point(659, 240);
            this.txt_cpassword.Name = "txt_cpassword";
            this.txt_cpassword.Size = new System.Drawing.Size(174, 20);
            this.txt_cpassword.TabIndex = 15;
            // 
            // btn_new
            // 
            this.btn_new.BackColor = System.Drawing.SystemColors.Highlight;
            this.btn_new.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_new.Location = new System.Drawing.Point(643, 306);
            this.btn_new.Name = "btn_new";
            this.btn_new.Size = new System.Drawing.Size(75, 32);
            this.btn_new.TabIndex = 16;
            this.btn_new.Text = "New";
            this.btn_new.UseVisualStyleBackColor = false;
            this.btn_new.Click += new System.EventHandler(this.btn_new_Click);
            // 
            // btn_reset2
            // 
            this.btn_reset2.BackColor = System.Drawing.SystemColors.Highlight;
            this.btn_reset2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reset2.Location = new System.Drawing.Point(758, 305);
            this.btn_reset2.Name = "btn_reset2";
            this.btn_reset2.Size = new System.Drawing.Size(75, 33);
            this.btn_reset2.TabIndex = 17;
            this.btn_reset2.Text = "Reset";
            this.btn_reset2.UseVisualStyleBackColor = false;
            this.btn_reset2.Click += new System.EventHandler(this.btn_reset2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(938, 453);
            this.Controls.Add(this.btn_reset2);
            this.Controls.Add(this.btn_new);
            this.Controls.Add(this.txt_cpassword);
            this.Controls.Add(this.txt_cgender);
            this.Controls.Add(this.txt_cmobileno);
            this.Controls.Add(this.txt_cemailid);
            this.Controls.Add(this.txt_cname);
            this.Controls.Add(this.lbl_cpassword);
            this.Controls.Add(this.lbl_cgender);
            this.Controls.Add(this.lbl_cmobileno);
            this.Controls.Add(this.lbl_cemail);
            this.Controls.Add(this.lbl_cname);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_login);
            this.Controls.Add(this.txt_password);
            this.Controls.Add(this.txt_loginid);
            this.Controls.Add(this.lbl_password);
            this.Controls.Add(this.lbl_login);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_login;
        private System.Windows.Forms.Label lbl_password;
        private System.Windows.Forms.TextBox txt_loginid;
        private System.Windows.Forms.TextBox txt_password;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.Label lbl_cname;
        private System.Windows.Forms.Label lbl_cemail;
        private System.Windows.Forms.Label lbl_cmobileno;
        private System.Windows.Forms.Label lbl_cgender;
        private System.Windows.Forms.Label lbl_cpassword;
        private System.Windows.Forms.TextBox txt_cname;
        private System.Windows.Forms.TextBox txt_cemailid;
        private System.Windows.Forms.TextBox txt_cmobileno;
        private System.Windows.Forms.TextBox txt_cgender;
        private System.Windows.Forms.TextBox txt_cpassword;
        private System.Windows.Forms.Button btn_new;
        private System.Windows.Forms.Button btn_reset2;
    }
}

