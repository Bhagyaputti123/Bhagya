﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login_cum_NewCustomer_Form
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

    

        private void btn_login_Click(object sender, EventArgs e)
        {
            int ID = Convert.ToInt32(txt_loginid.Text);
            string password = txt_password.Text;
            try
            {
                CustomerDAL dal = new CustomerDAL();
                bool status = dal.Login(ID, password);
                if (status)
                {
                    MessageBox.Show("valid user");
                    Test.customerid = Convert.ToInt32(txt_loginid.Text);
                    Home_Form frm = new Home_Form();
                    frm.Show();
                }
                else
                {
                    MessageBox.Show("invalid user");
                }


            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
            finally
            {
                MessageBox.Show("finally block");
            }

        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_loginid.Text = string.Empty;
            txt_password.Text = string.Empty;
        }

        private void btn_new_Click(object sender, EventArgs e)
        {
            if(txt_cname.Text==string.Empty)
            {
                MessageBox.Show("enter name");
            }
            else if(txt_cemailid.Text==string.Empty)
            {
                MessageBox.Show("enter mail id");
            }
            else if (txt_cmobileno.Text == string.Empty)
            {
                MessageBox.Show("enter mobile no");
            }
            else if (txt_cgender.Text == string.Empty)
            {
                MessageBox.Show("enter gender");
            }
           // else if (txt_password.Text == string.Empty)
            //{
            //    MessageBox.Show("enter password");
           // }
            else
            {
                string name = txt_cname.Text;
                string mailid = txt_cemailid.Text;
                string mobilno = txt_cmobileno.Text;
                string gender = txt_cgender.Text;
                string pwd = txt_cpassword.Text;
                Custmer obj = new Custmer();
                obj.customername = name;
                obj.customeremail = mailid;
                obj.customermobileno = mobilno;
                obj.customergender = gender;
                obj.customerpassword = pwd;

                CustomerDAL dal = new CustomerDAL();
                int id = dal.Addcustomer(obj);
                MessageBox.Show("customer added:" + id);

            }



        }

        private void btn_reset2_Click(object sender, EventArgs e)
        {
            txt_cname.Text = string.Empty;
            txt_cemailid.Text = string.Empty;
            txt_cmobileno.Text = string.Empty;
            txt_cgender.Text = string.Empty;
            txt_password.Text = string.Empty;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
    }



    

