﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login_cum_NewCustomer_Form
{
    public partial class NewAccount_Form : Form
    {
        public NewAccount_Form()
        {
            InitializeComponent();
        }

        private void btn_new_Click(object sender, EventArgs e)
        {
            if(txt_custid.Text==string.Empty)
            {
                MessageBox.Show("enter customer id");
            }
            else if(txt_acctbal.Text==string.Empty)
            {
                MessageBox.Show("enter balance");

            }
            else if(txt_accopendate.Text==string.Empty)
            {
                MessageBox.Show("enter account opeing date");
            }
            else if(combo_Accounttype.Text==string.Empty)
            {
                MessageBox.Show("enter account type");
            }
            else
            {
                int cid = Convert.ToInt32(txt_custid.Text);
                int accbal =Convert.ToInt32 (txt_acctbal.Text);
                string acctype = combo_Accounttype.Text;
                DateTime accopendate = Convert.ToDateTime(txt_accopendate.Text);
                Account obj = new Account();
                obj.customerid = cid;
                obj.accountbalance = accbal;
                obj.accounttype = acctype;
                obj.accountopeningdate = accopendate;
                AccountsDAL dal = new AccountsDAL();
                int id = dal.addAccount(obj);
                MessageBox.Show("account added:" + id);

            }
        }

        private void btn_reset1_Click(object sender, EventArgs e)
        {
            txt_custid.Text = string.Empty;
            txt_acctbal.Text = string.Empty;
            combo_Accounttype.Text = string.Empty;
            txt_accopendate.Text = string.Empty;

        }

        private void combo_Accounttype_SelectedIndexChanged(object sender, EventArgs e)
        {
            



        }

        private void NewAccount_Form_Load(object sender, EventArgs e)
        {
            AccountsDAL dal = new AccountsDAL();

            txt_custid.Text = Test.customerid.ToString();
            combo_Accounttype.Items.Add("savings");
            combo_Accounttype.Items.Add("current");
            
        }

        private void txt_custid_TextChanged(object sender, EventArgs e)
        {
            txt_custid.Text = Test.customerid.ToString();
            
        }
    }
}
