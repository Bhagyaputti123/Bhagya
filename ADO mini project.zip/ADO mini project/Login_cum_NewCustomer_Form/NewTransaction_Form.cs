﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login_cum_NewCustomer_Form
{
    public partial class NewTransaction_Form : Form
    {
        public NewTransaction_Form()
        {
            InitializeComponent();
        }

        private void btn_newtrans_Click(object sender, EventArgs e)
        {
            if(combo_accountid.Text == string.Empty)
            {
                MessageBox.Show("enter account id");
            }
            else if (txt_amount.Text == string.Empty)
            {
                MessageBox.Show("enter amount");

            }
            else if (combo_transactiontype.Text == string.Empty)
            {
                MessageBox.Show("enter transaction type");
            }
            else if (txt_transactiondate.Text == string.Empty)
            {
                MessageBox.Show("enter transaction date");
            }
            else
            {
                
            
                    int aid = Convert.ToInt32(combo_accountid.Text);
                    int amount= Convert.ToInt32(txt_amount.Text);
                    string transtype = combo_transactiontype.Text;
                    DateTime transdate = Convert.ToDateTime(txt_transactiondate.Text);
                    Transaction obj = new Transaction();
                    obj.accountid = aid;
                    obj.amount = amount;
                    obj.transactiontype = transtype;
                    obj.transactiondate = transdate;
                    TransactionsDAL dal =new TransactionsDAL();
                    AccountsDAL dal1 = new AccountsDAL();
                    int accbal = dal1.accBalance(Convert.ToInt32(combo_accountid.Text));
                   // int id = dal.addTransaction(obj);
                    MessageBox.Show("amount"+accbal);
                   if(obj.transactiontype=="credit")
                {
                    int id = dal.addTransaction(obj);
                    MessageBox.Show("transaction id is:" + id);
                }
                if(obj.transactiontype=="debit")
                {
                    if (obj.amount < accbal)
                    {
                        int id = dal.addTransaction(obj);
                        MessageBox.Show("transaction id is:" + id);
                    }
                    else
                    {
                        MessageBox.Show("insufficient balance:" + accbal);
                    }
                }
            }
       }

        private void combo_transactiontype_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void NewTransaction_Form_Load(object sender, EventArgs e)
        {
            AccountsDAL dal = new AccountsDAL();
            List<int> list = dal.accounts(Test.customerid);
            foreach(var s in list)
            {
                combo_accountid.Items.Add(s);
            }
            
            combo_transactiontype.Items.Add("credit");
            combo_transactiontype.Items.Add("debit");


            
          }

        private void txt_accountid_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {



        }
    }
 }
    

