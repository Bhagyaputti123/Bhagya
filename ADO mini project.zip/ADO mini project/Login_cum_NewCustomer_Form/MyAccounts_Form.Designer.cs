﻿namespace Login_cum_NewCustomer_Form
{
    partial class MyAccounts_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_cid = new System.Windows.Forms.Label();
            this.txt_customerid = new System.Windows.Forms.TextBox();
            this.btn_show = new System.Windows.Forms.Button();
            this.dg_myaccount = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dg_myaccount)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_cid
            // 
            this.lbl_cid.AutoSize = true;
            this.lbl_cid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cid.Location = new System.Drawing.Point(90, 86);
            this.lbl_cid.Name = "lbl_cid";
            this.lbl_cid.Size = new System.Drawing.Size(127, 25);
            this.lbl_cid.TabIndex = 0;
            this.lbl_cid.Text = "Customer ID:";
            // 
            // txt_customerid
            // 
            this.txt_customerid.Location = new System.Drawing.Point(283, 86);
            this.txt_customerid.Name = "txt_customerid";
            this.txt_customerid.Size = new System.Drawing.Size(183, 20);
            this.txt_customerid.TabIndex = 1;
            // 
            // btn_show
            // 
            this.btn_show.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_show.Location = new System.Drawing.Point(173, 170);
            this.btn_show.Name = "btn_show";
            this.btn_show.Size = new System.Drawing.Size(75, 41);
            this.btn_show.TabIndex = 2;
            this.btn_show.Text = "Show";
            this.btn_show.UseVisualStyleBackColor = true;
            this.btn_show.Click += new System.EventHandler(this.btn_show_Click);
            // 
            // dg_myaccount
            // 
            this.dg_myaccount.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_myaccount.Location = new System.Drawing.Point(13, 251);
            this.dg_myaccount.Name = "dg_myaccount";
            this.dg_myaccount.Size = new System.Drawing.Size(486, 171);
            this.dg_myaccount.TabIndex = 3;
            this.dg_myaccount.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dg_myaccount_CellContentClick);
            // 
            // MyAccounts_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(511, 434);
            this.Controls.Add(this.dg_myaccount);
            this.Controls.Add(this.btn_show);
            this.Controls.Add(this.txt_customerid);
            this.Controls.Add(this.lbl_cid);
            this.Name = "MyAccounts_Form";
            this.Text = "MyAccounts_Form";
            ((System.ComponentModel.ISupportInitialize)(this.dg_myaccount)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_cid;
        private System.Windows.Forms.TextBox txt_customerid;
        private System.Windows.Forms.Button btn_show;
        private System.Windows.Forms.DataGridView dg_myaccount;
    }
}