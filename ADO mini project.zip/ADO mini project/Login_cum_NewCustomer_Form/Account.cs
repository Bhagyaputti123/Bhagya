﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Login_cum_NewCustomer_Form
{
    class Account
    {
        public int accountid { get; set; }
        public int customerid { get; set; }
        public int accountbalance { get; set; }
        public string accounttype { get; set; }
        public DateTime accountopeningdate { get; set; }

     }
}
