﻿namespace Login_cum_NewCustomer_Form
{
    partial class NewAccount_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_cusid = new System.Windows.Forms.Label();
            this.lbl_accbalance = new System.Windows.Forms.Label();
            this.lbl_acctype = new System.Windows.Forms.Label();
            this.lbl_accopendate = new System.Windows.Forms.Label();
            this.txt_custid = new System.Windows.Forms.TextBox();
            this.txt_acctbal = new System.Windows.Forms.TextBox();
            this.txt_accopendate = new System.Windows.Forms.TextBox();
            this.btn_new = new System.Windows.Forms.Button();
            this.btn_reset1 = new System.Windows.Forms.Button();
            this.combo_Accounttype = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lbl_cusid
            // 
            this.lbl_cusid.AutoSize = true;
            this.lbl_cusid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cusid.Location = new System.Drawing.Point(59, 47);
            this.lbl_cusid.Name = "lbl_cusid";
            this.lbl_cusid.Size = new System.Drawing.Size(122, 25);
            this.lbl_cusid.TabIndex = 0;
            this.lbl_cusid.Text = "CustomerID:";
            // 
            // lbl_accbalance
            // 
            this.lbl_accbalance.AutoSize = true;
            this.lbl_accbalance.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_accbalance.Location = new System.Drawing.Point(62, 102);
            this.lbl_accbalance.Name = "lbl_accbalance";
            this.lbl_accbalance.Size = new System.Drawing.Size(166, 25);
            this.lbl_accbalance.TabIndex = 1;
            this.lbl_accbalance.Text = "Account Balance:";
            // 
            // lbl_acctype
            // 
            this.lbl_acctype.AutoSize = true;
            this.lbl_acctype.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_acctype.Location = new System.Drawing.Point(59, 165);
            this.lbl_acctype.Name = "lbl_acctype";
            this.lbl_acctype.Size = new System.Drawing.Size(140, 25);
            this.lbl_acctype.TabIndex = 2;
            this.lbl_acctype.Text = "Account Type:";
            // 
            // lbl_accopendate
            // 
            this.lbl_accopendate.AutoSize = true;
            this.lbl_accopendate.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_accopendate.Location = new System.Drawing.Point(59, 229);
            this.lbl_accopendate.Name = "lbl_accopendate";
            this.lbl_accopendate.Size = new System.Drawing.Size(216, 25);
            this.lbl_accopendate.TabIndex = 3;
            this.lbl_accopendate.Text = "Account Opening Date:";
            // 
            // txt_custid
            // 
            this.txt_custid.Location = new System.Drawing.Point(374, 52);
            this.txt_custid.Name = "txt_custid";
            this.txt_custid.Size = new System.Drawing.Size(203, 20);
            this.txt_custid.TabIndex = 4;
            this.txt_custid.TextChanged += new System.EventHandler(this.txt_custid_TextChanged);
            // 
            // txt_acctbal
            // 
            this.txt_acctbal.Location = new System.Drawing.Point(374, 108);
            this.txt_acctbal.Name = "txt_acctbal";
            this.txt_acctbal.Size = new System.Drawing.Size(203, 20);
            this.txt_acctbal.TabIndex = 5;
            // 
            // txt_accopendate
            // 
            this.txt_accopendate.Location = new System.Drawing.Point(374, 235);
            this.txt_accopendate.Name = "txt_accopendate";
            this.txt_accopendate.Size = new System.Drawing.Size(203, 20);
            this.txt_accopendate.TabIndex = 7;
            // 
            // btn_new
            // 
            this.btn_new.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_new.Location = new System.Drawing.Point(65, 333);
            this.btn_new.Name = "btn_new";
            this.btn_new.Size = new System.Drawing.Size(75, 45);
            this.btn_new.TabIndex = 8;
            this.btn_new.Text = "New";
            this.btn_new.UseVisualStyleBackColor = true;
            this.btn_new.Click += new System.EventHandler(this.btn_new_Click);
            // 
            // btn_reset1
            // 
            this.btn_reset1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reset1.Location = new System.Drawing.Point(257, 333);
            this.btn_reset1.Name = "btn_reset1";
            this.btn_reset1.Size = new System.Drawing.Size(75, 45);
            this.btn_reset1.TabIndex = 9;
            this.btn_reset1.Text = "Reset";
            this.btn_reset1.UseVisualStyleBackColor = true;
            this.btn_reset1.Click += new System.EventHandler(this.btn_reset1_Click);
            // 
            // combo_Accounttype
            // 
            this.combo_Accounttype.FormattingEnabled = true;
            this.combo_Accounttype.Location = new System.Drawing.Point(374, 168);
            this.combo_Accounttype.Name = "combo_Accounttype";
            this.combo_Accounttype.Size = new System.Drawing.Size(203, 21);
            this.combo_Accounttype.TabIndex = 10;
            this.combo_Accounttype.SelectedIndexChanged += new System.EventHandler(this.combo_Accounttype_SelectedIndexChanged);
            // 
            // NewAccount_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(716, 450);
            this.Controls.Add(this.combo_Accounttype);
            this.Controls.Add(this.btn_reset1);
            this.Controls.Add(this.btn_new);
            this.Controls.Add(this.txt_accopendate);
            this.Controls.Add(this.txt_acctbal);
            this.Controls.Add(this.txt_custid);
            this.Controls.Add(this.lbl_accopendate);
            this.Controls.Add(this.lbl_acctype);
            this.Controls.Add(this.lbl_accbalance);
            this.Controls.Add(this.lbl_cusid);
            this.Name = "NewAccount_Form";
            this.Text = "NewAccount_Form";
            this.Load += new System.EventHandler(this.NewAccount_Form_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_cusid;
        private System.Windows.Forms.Label lbl_accbalance;
        private System.Windows.Forms.Label lbl_acctype;
        private System.Windows.Forms.Label lbl_accopendate;
        private System.Windows.Forms.TextBox txt_custid;
        private System.Windows.Forms.TextBox txt_acctbal;
        private System.Windows.Forms.TextBox txt_accopendate;
        private System.Windows.Forms.Button btn_new;
        private System.Windows.Forms.Button btn_reset1;
        private System.Windows.Forms.ComboBox combo_Accounttype;
    }
}