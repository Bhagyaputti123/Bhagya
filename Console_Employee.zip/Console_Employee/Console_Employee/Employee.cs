﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Employee
{
    class Employee
    {

        public int EmployeeID { get; set; }
        public string employeeName { get; set; }
        public int employeeSalary { get; set; }
        public int empExperience { get; set; }
        public string employeeCity { get; set; }
    }
}
