﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Employee
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> emplist = new List<Employee>();
            emplist.Add(new Employee { EmployeeID = 1, employeeName = "bhagya", employeeSalary = 20000, empExperience = 6, employeeCity = "BGL" });
            emplist.Add(new Employee { EmployeeID = 2, employeeName = "Anusha", employeeSalary = 18000, empExperience = 5, employeeCity = "hyd" });
            emplist.Add(new Employee { EmployeeID = 3, employeeName = "madhu", employeeSalary = 25000, empExperience = 1, employeeCity = "tumkur" });
            emplist.Add(new Employee { EmployeeID = 4, employeeName = "bhavya", employeeSalary = 55000, empExperience = 3, employeeCity = "BGL" });

            List<EmployeeLeaves> empleavelist = new List<EmployeeLeaves>();
            empleavelist.Add(new EmployeeLeaves { leaveID = 100, leavetype = "casual", reason = "not well", empID = 1 });
            empleavelist.Add(new EmployeeLeaves { leaveID = 101, leavetype = "festival", reason = "marriage", empID = 3 });
            empleavelist.Add(new EmployeeLeaves { leaveID = 103, leavetype = "casual", reason = "sick", empID = 4 });
            empleavelist.Add(new EmployeeLeaves { leaveID = 104, leavetype = "festival", reason = "trip", empID = 2 });

            //linq queries

            var count = (from e in emplist
                         where e.empExperience > 5
                         select e).Count();
            Console.WriteLine(count);
            

            var empdata = (from e in emplist
                       where e.employeeSalary > 50000
                       select new { ID=e.EmployeeID, Name=e.employeeName,salary= e.employeeSalary, city=e.employeeCity,exp= e.empExperience });
            foreach(var x in empdata)
            {
                Console.WriteLine(x.ID + " " + x.Name + " " + x.salary + " " + x.city + " " + x.exp);

            }

            string city = "BGL";
            var data = (from e in emplist
                        where e.employeeCity == city
                        select e);
            foreach(var m in data)
            {
                Console.WriteLine(m.employeeName + " " + m.employeeCity);
            }

            var employeedata = (from e in emplist
                                where e.employeeName.StartsWith("a")
                                select new { EID = e.EmployeeID, name = e.employeeName, city = e.employeeCity });
            foreach(var k in employeedata)
            {
                Console.WriteLine(k.EID + " " + k.name + " " + k.city);
            }

            var leaves = (from e in emplist
                          join l in empleavelist
                          on e.EmployeeID equals l.empID
                          select new { lid = l.leaveID, ltype = l.leavetype, Reason = l.reason, empid = l.empID });
            foreach(var s in leaves)
            {
                Console.WriteLine(s.lid + " " + s.ltype + " " + s.Reason + " " + s.empid);
            }

            //Lambda expression

            var s2 = emplist.Count((e) => e.empExperience > 5);
            Console.WriteLine(s2);


            var s1 = emplist.Where((e) => e.employeeSalary > 50000);
            foreach(var d in s1)
            {
                Console.WriteLine(d.EmployeeID + " " + d.employeeName + " " + d.employeeSalary);
            }

            var s3 = emplist.Where((e) => e.employeeCity == "BGL");
            foreach(var z in s3)
            {
                Console.WriteLine(z.EmployeeID + " " + z.employeeName + " " + z.employeeCity);
            }

            var s4 = emplist.Join(empleavelist, (e) => e.EmployeeID, (l) => l.empID, (e, l) => new { EID = e.EmployeeID, LID = l.leaveID, Ename = e.employeeName });
            foreach(var p in s4)
            {
                Console.WriteLine(p.EID + " " + p.Ename + " " + p.LID);
            }

            var s5 = emplist.Where((e) => e.employeeName.StartsWith("a"));
            foreach (var j in s5)
            {
                Console.WriteLine(j.EmployeeID+"  "+j.employeeName+" "+j.employeeSalary+" "+j.employeeCity+" "+j.empExperience);

            }

           Console.ReadLine();
        }
    }
}
