﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Employee
{
    class EmployeeLeaves
    {
        public int leaveID { get; set; }
        public string leavetype { get; set; }
        public string reason { get; set; }
        public int empID { get; set; }


    }
}
