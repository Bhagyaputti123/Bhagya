﻿namespace Win_frm_order
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radio_paymentcash = new System.Windows.Forms.RadioButton();
            this.radio_paymentcard = new System.Windows.Forms.RadioButton();
            this.btn_placeorder = new System.Windows.Forms.Button();
            this.lbl_orderid = new System.Windows.Forms.Label();
            this.txt_orderid = new System.Windows.Forms.TextBox();
            this.lbl_cname1 = new System.Windows.Forms.Label();
            this.txt_Customername = new System.Windows.Forms.TextBox();
            this.lbl_itemid = new System.Windows.Forms.Label();
            this.txt_itemid = new System.Windows.Forms.TextBox();
            this.lbl_itemqty = new System.Windows.Forms.Label();
            this.txt_itemqty = new System.Windows.Forms.TextBox();
            this.lbl_Itemprice = new System.Windows.Forms.Label();
            this.txt_itemprice = new System.Windows.Forms.TextBox();
            this.lbl_Deliveryaddr = new System.Windows.Forms.Label();
            this.txt_deliveraddr = new System.Windows.Forms.TextBox();
            this.comb_ordercity = new System.Windows.Forms.ComboBox();
            this.lbl_paymentoption = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // radio_paymentcash
            // 
            this.radio_paymentcash.AutoSize = true;
            this.radio_paymentcash.Location = new System.Drawing.Point(40, 423);
            this.radio_paymentcash.Name = "radio_paymentcash";
            this.radio_paymentcash.Size = new System.Drawing.Size(49, 17);
            this.radio_paymentcash.TabIndex = 7;
            this.radio_paymentcash.TabStop = true;
            this.radio_paymentcash.Text = "Cash";
            this.radio_paymentcash.UseVisualStyleBackColor = true;
            this.radio_paymentcash.CheckedChanged += new System.EventHandler(this.radio_Paymentoption_CheckedChanged);
            // 
            // radio_paymentcard
            // 
            this.radio_paymentcard.AutoSize = true;
            this.radio_paymentcard.Location = new System.Drawing.Point(40, 447);
            this.radio_paymentcard.Name = "radio_paymentcard";
            this.radio_paymentcard.Size = new System.Drawing.Size(47, 17);
            this.radio_paymentcard.TabIndex = 8;
            this.radio_paymentcard.TabStop = true;
            this.radio_paymentcard.Text = "Card";
            this.radio_paymentcard.UseVisualStyleBackColor = true;
            // 
            // btn_placeorder
            // 
            this.btn_placeorder.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_placeorder.Location = new System.Drawing.Point(40, 498);
            this.btn_placeorder.Name = "btn_placeorder";
            this.btn_placeorder.Size = new System.Drawing.Size(121, 42);
            this.btn_placeorder.TabIndex = 9;
            this.btn_placeorder.Tag = "PlaceOrder";
            this.btn_placeorder.Text = "PlaceOrder";
            this.btn_placeorder.UseVisualStyleBackColor = true;
            this.btn_placeorder.Click += new System.EventHandler(this.btn_placeorder_Click);
            // 
            // lbl_orderid
            // 
            this.lbl_orderid.AutoSize = true;
            this.lbl_orderid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_orderid.Location = new System.Drawing.Point(40, 35);
            this.lbl_orderid.Name = "lbl_orderid";
            this.lbl_orderid.Size = new System.Drawing.Size(87, 25);
            this.lbl_orderid.TabIndex = 10;
            this.lbl_orderid.Text = "OrderID:";
            // 
            // txt_orderid
            // 
            this.txt_orderid.Location = new System.Drawing.Point(212, 39);
            this.txt_orderid.Name = "txt_orderid";
            this.txt_orderid.Size = new System.Drawing.Size(100, 20);
            this.txt_orderid.TabIndex = 11;
            // 
            // lbl_cname1
            // 
            this.lbl_cname1.AutoSize = true;
            this.lbl_cname1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cname1.Location = new System.Drawing.Point(45, 84);
            this.lbl_cname1.Name = "lbl_cname1";
            this.lbl_cname1.Size = new System.Drawing.Size(155, 25);
            this.lbl_cname1.TabIndex = 12;
            this.lbl_cname1.Text = "CustomerName:";
            // 
            // txt_Customername
            // 
            this.txt_Customername.Location = new System.Drawing.Point(212, 88);
            this.txt_Customername.Name = "txt_Customername";
            this.txt_Customername.Size = new System.Drawing.Size(100, 20);
            this.txt_Customername.TabIndex = 13;
            // 
            // lbl_itemid
            // 
            this.lbl_itemid.AutoSize = true;
            this.lbl_itemid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_itemid.Location = new System.Drawing.Point(50, 130);
            this.lbl_itemid.Name = "lbl_itemid";
            this.lbl_itemid.Size = new System.Drawing.Size(74, 25);
            this.lbl_itemid.TabIndex = 14;
            this.lbl_itemid.Text = "ItemID:";
            // 
            // txt_itemid
            // 
            this.txt_itemid.Location = new System.Drawing.Point(212, 134);
            this.txt_itemid.Name = "txt_itemid";
            this.txt_itemid.Size = new System.Drawing.Size(100, 20);
            this.txt_itemid.TabIndex = 15;
            // 
            // lbl_itemqty
            // 
            this.lbl_itemqty.AutoSize = true;
            this.lbl_itemqty.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_itemqty.Location = new System.Drawing.Point(50, 182);
            this.lbl_itemqty.Name = "lbl_itemqty";
            this.lbl_itemqty.Size = new System.Drawing.Size(128, 25);
            this.lbl_itemqty.TabIndex = 17;
            this.lbl_itemqty.Text = "ItemQuantity:";
            // 
            // txt_itemqty
            // 
            this.txt_itemqty.Location = new System.Drawing.Point(212, 186);
            this.txt_itemqty.Name = "txt_itemqty";
            this.txt_itemqty.Size = new System.Drawing.Size(100, 20);
            this.txt_itemqty.TabIndex = 18;
            // 
            // lbl_Itemprice
            // 
            this.lbl_Itemprice.AutoSize = true;
            this.lbl_Itemprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Itemprice.Location = new System.Drawing.Point(50, 226);
            this.lbl_Itemprice.Name = "lbl_Itemprice";
            this.lbl_Itemprice.Size = new System.Drawing.Size(99, 25);
            this.lbl_Itemprice.TabIndex = 19;
            this.lbl_Itemprice.Text = "ItemPrice:";
            // 
            // txt_itemprice
            // 
            this.txt_itemprice.Location = new System.Drawing.Point(212, 230);
            this.txt_itemprice.Name = "txt_itemprice";
            this.txt_itemprice.Size = new System.Drawing.Size(100, 20);
            this.txt_itemprice.TabIndex = 20;
            // 
            // lbl_Deliveryaddr
            // 
            this.lbl_Deliveryaddr.AutoSize = true;
            this.lbl_Deliveryaddr.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Deliveryaddr.Location = new System.Drawing.Point(50, 264);
            this.lbl_Deliveryaddr.Name = "lbl_Deliveryaddr";
            this.lbl_Deliveryaddr.Size = new System.Drawing.Size(161, 25);
            this.lbl_Deliveryaddr.TabIndex = 21;
            this.lbl_Deliveryaddr.Text = "DeliveryAddress:";
            // 
            // txt_deliveraddr
            // 
            this.txt_deliveraddr.Location = new System.Drawing.Point(218, 268);
            this.txt_deliveraddr.Name = "txt_deliveraddr";
            this.txt_deliveraddr.Size = new System.Drawing.Size(188, 20);
            this.txt_deliveraddr.TabIndex = 23;
            // 
            // comb_ordercity
            // 
            this.comb_ordercity.FormattingEnabled = true;
            this.comb_ordercity.Location = new System.Drawing.Point(50, 315);
            this.comb_ordercity.Name = "comb_ordercity";
            this.comb_ordercity.Size = new System.Drawing.Size(121, 21);
            this.comb_ordercity.TabIndex = 24;
            this.comb_ordercity.SelectedIndexChanged += new System.EventHandler(this.comb_ordercity_SelectedIndexChanged);
            // 
            // lbl_paymentoption
            // 
            this.lbl_paymentoption.AutoSize = true;
            this.lbl_paymentoption.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_paymentoption.Location = new System.Drawing.Point(50, 371);
            this.lbl_paymentoption.Name = "lbl_paymentoption";
            this.lbl_paymentoption.Size = new System.Drawing.Size(142, 25);
            this.lbl_paymentoption.TabIndex = 25;
            this.lbl_paymentoption.Text = "Paymentoption";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(671, 566);
            this.Controls.Add(this.lbl_paymentoption);
            this.Controls.Add(this.comb_ordercity);
            this.Controls.Add(this.txt_deliveraddr);
            this.Controls.Add(this.lbl_Deliveryaddr);
            this.Controls.Add(this.txt_itemprice);
            this.Controls.Add(this.lbl_Itemprice);
            this.Controls.Add(this.txt_itemqty);
            this.Controls.Add(this.lbl_itemqty);
            this.Controls.Add(this.txt_itemid);
            this.Controls.Add(this.lbl_itemid);
            this.Controls.Add(this.txt_Customername);
            this.Controls.Add(this.lbl_cname1);
            this.Controls.Add(this.txt_orderid);
            this.Controls.Add(this.lbl_orderid);
            this.Controls.Add(this.btn_placeorder);
            this.Controls.Add(this.radio_paymentcard);
            this.Controls.Add(this.radio_paymentcash);
            this.Name = "Form1";
            this.Text = " ";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.RadioButton radio_paymentcash;
        private System.Windows.Forms.RadioButton radio_paymentcard;
        private System.Windows.Forms.Button btn_placeorder;
        private System.Windows.Forms.Label lbl_orderid;
        private System.Windows.Forms.TextBox txt_orderid;
        private System.Windows.Forms.Label lbl_cname1;
        private System.Windows.Forms.TextBox txt_Customername;
        private System.Windows.Forms.Label lbl_itemid;
        private System.Windows.Forms.TextBox txt_itemid;
        private System.Windows.Forms.Label lbl_itemqty;
        private System.Windows.Forms.TextBox txt_itemqty;
        private System.Windows.Forms.Label lbl_Itemprice;
        private System.Windows.Forms.TextBox txt_itemprice;
        private System.Windows.Forms.Label lbl_Deliveryaddr;
        private System.Windows.Forms.TextBox txt_deliveraddr;
        private System.Windows.Forms.ComboBox comb_ordercity;
        private System.Windows.Forms.Label lbl_paymentoption;
    }
}

