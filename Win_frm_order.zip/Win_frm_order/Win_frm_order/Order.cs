﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_frm_order
{
    class Order
    {
        private int OrderID;
        private string Customername;
        private int itemID;
        private int Itemqty;
        private int Itemprice;
        private string DeliveryAddress;
        private string OrderCity;
        private string Paymentoption;
        
        
        public Order(int OrderID,string Customername,int itemID,int Itemqty,int Itemprice,string DeliveryAddress,string OrderCity,string Paymentoption)
        {
            this.OrderID = OrderID;
            this.Customername = Customername;
            this.itemID = itemID;
            this.Itemqty = Itemqty;
            this.Itemprice = Itemprice;
            this.DeliveryAddress = DeliveryAddress;
            this.OrderCity = OrderCity;
            this.Paymentoption = Paymentoption;
        }
        public int Getordervalue()
        {
            int total = Itemqty * Itemprice;
            return total;
        }
    }
}
