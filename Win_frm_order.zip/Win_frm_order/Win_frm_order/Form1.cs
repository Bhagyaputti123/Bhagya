﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_frm_order
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_placeorder_Click(object sender, EventArgs e)
        {
            if(txt_orderid.Text==string.Empty)
            {
                MessageBox.Show("enter the order id");
            }
            else if(txt_Customername.Text==string.Empty)
            {
                MessageBox.Show("enter the customer name");
            }
            else if(txt_itemid.Text==string.Empty)
            {
                MessageBox.Show("enter the item ID");
            }
            else if(txt_itemqty.Text==string.Empty)
            {
                MessageBox.Show("enter the item quantity");
            }
            else if(txt_itemprice.Text==string.Empty)
            {
                MessageBox.Show("enter the item price");
            }
            else if(txt_deliveraddr.Text==string.Empty)
            {
                MessageBox.Show("enter the delivery address");
            }
            else if(comb_ordercity.Text==string.Empty)
            {
                MessageBox.Show("enter the ordred city");
            }
            else if(radio_paymentcash.Checked==false && radio_paymentcard.Checked==false)
            {
                MessageBox.Show("select payment");
            }

           
            else
            {

                int ID = Convert.ToInt32(txt_orderid.Text);
                string name = txt_Customername.Text;
                int iID = Convert.ToInt32(txt_itemid.Text);
                int iqty = Convert.ToInt32(txt_itemqty.Text);
                int iprice = Convert.ToInt32(txt_itemprice.Text);
                string Daddres = txt_deliveraddr.Text;
                string OrCity = comb_ordercity.Text;
                string payment = string.Empty;
                if(radio_paymentcash.Checked)
                {
                    payment = "cash";
                }
                else
                {
                    payment = "card";
                }
                
                Order obj = new Order(ID,name,iID,iqty,iprice,Daddres,OrCity,payment);
               int s= obj.Getordervalue();
                MessageBox.Show("value:" +s );

            }
            
            
        }

        private void comb_ordercity_SelectedIndexChanged(object sender, EventArgs e)
        {
        }


        private void radio_Paymentoption_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comb_ordercity.Items.Add("Banglore");
            comb_ordercity.Items.Add("Tumkur");
            comb_ordercity.Items.Add("Chennai");
            comb_ordercity.Items.Add("Kerala");
        }
    
    }
}
