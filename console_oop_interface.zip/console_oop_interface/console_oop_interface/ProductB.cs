﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace console_oop_interface
{
    class ProductB:IProductTransport
    {
        private int PID;
        private string Pname;
        public ProductB(int PID,string Pname)
        {
            this.PID = PID;
            this.Pname = Pname;
        }
        public int Getprice()
        {
            return 20000;

        }
        public string GetDetails()
        {
            return this.PID + " " + this.Pname;
        }
        public void start()
        { }
        public void stop()
        { }

        public string GetAddress()
        {
            return "ABC,Chennai";
        }
    }
}
