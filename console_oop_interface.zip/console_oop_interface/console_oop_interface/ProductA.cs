﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace console_oop_interface
{
    class ProductA : IProductTransport
    {
        private int Productid;
        private string Productname;
        public ProductA(int Productid, string Productname)
        {
            this.Productid = Productid;
            this.Productname = Productname;

        }
        public int Getprice()
        {
            return 2000;

        }
        public string GetDeatils()
        {
            return this.Productid + " " + this.Productname;
        }

        public string GetAddress()
        {
            return "XYZ,Pune";
        }
    }
}
