﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ADO
{
    public partial class Frm_Find : Form
    {
        public Frm_Find()
        {
            InitializeComponent();
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            if (txt_empid.Text == string.Empty)

            {
                MessageBox.Show("enter id:");
            }
            else
            {
                int ID = Convert.ToInt32(txt_empid.Text);
                EmployeeDAL dal = new EmployeeDAL();
                Employee emp = dal.Find(ID);
                if (emp != null)
                {
                    txt_empname.Text = emp.employeename;
                    txt_empcity.Text = emp.employeecity;
                    txt_emppassword.Text = emp.employeepassword;
                    txt_empDoj.Text = emp.employeeDOJ.ToString();

                }
                else
                {
                    MessageBox.Show("not found");
                }
            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            if (txt_empid.Text == string.Empty)
            {
                MessageBox.Show("enter id:");

            }
            else if (txt_empcity.Text == string.Empty)
            {
                MessageBox.Show("enter city");
            }
            else if (txt_emppassword.Text == string.Empty)
            {
                MessageBox.Show("enter pasword");
            }
            else
            {

                int ID = Convert.ToInt32(txt_empid.Text);
                string city = txt_empcity.Text;
                string password = txt_emppassword.Text;


                EmployeeDAL dal = new EmployeeDAL();
                bool status = dal.update(ID, city, password);
                if (status)
                {
                    MessageBox.Show("updated");
                }
                else
                {
                    MessageBox.Show("not updated");
                }
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if(txt_empid.Text==string.Empty)
            {
                MessageBox.Show("enter id");

            }
            else
            {
                int ID = Convert.ToInt32(txt_empid.Text);
                EmployeeDAL dal = new EmployeeDAL();
                bool status = dal.delete(ID);
                if(status)
                {
                    MessageBox.Show("deleted");

                }
                else
                {
                    MessageBox.Show("not deleted");
                }
            }
        }
    }
}
