﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ADO
{
    public partial class Frm_Login : Form
    {
        public Frm_Login()
        {
            InitializeComponent();
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            int ID = Convert.ToInt32(txt_loginid.Text);
            string password = txt_password.Text;
            try
            {

                EmployeeDAL dal = new EmployeeDAL();
                bool status = dal.Login(ID, password);
                if (status)
                {

                    MessageBox.Show("valid user");

                }
                else
                {
                    MessageBox.Show("invalid user");
                }
            }
           // catch(System.Data.SqlClient.SqlException exp)
           // {
            //    MessageBox.Show("sql error");
            //}
            catch(Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
            finally
            {
                MessageBox.Show("finally block");
            }


        }

        private void btn_loginwithsql_Click(object sender, EventArgs e)
        {
            string id = txt_loginid.Text;
            string password = txt_password.Text;
            EmployeeDAL dal = new EmployeeDAL();
            bool status = dal.LoginSqlInjection(id, password);
            if(status)
            {
                MessageBox.Show("valid user");

            }
            else
            {
                MessageBox.Show("invalid user");
            }
        }
    }
}
