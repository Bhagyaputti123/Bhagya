﻿namespace Win_ADO
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_empname = new System.Windows.Forms.Label();
            this.lbl_empcity = new System.Windows.Forms.Label();
            this.lbl_emppassword = new System.Windows.Forms.Label();
            this.txt_empname = new System.Windows.Forms.TextBox();
            this.txt_empcity = new System.Windows.Forms.TextBox();
            this.txt_emppassword = new System.Windows.Forms.TextBox();
            this.btn_newemp = new System.Windows.Forms.Button();
            this.btn_reset = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_empname
            // 
            this.lbl_empname.AutoSize = true;
            this.lbl_empname.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_empname.Location = new System.Drawing.Point(45, 60);
            this.lbl_empname.Name = "lbl_empname";
            this.lbl_empname.Size = new System.Drawing.Size(148, 25);
            this.lbl_empname.TabIndex = 0;
            this.lbl_empname.Text = "Employeename";
            // 
            // lbl_empcity
            // 
            this.lbl_empcity.AutoSize = true;
            this.lbl_empcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_empcity.Location = new System.Drawing.Point(50, 121);
            this.lbl_empcity.Name = "lbl_empcity";
            this.lbl_empcity.Size = new System.Drawing.Size(133, 25);
            this.lbl_empcity.TabIndex = 1;
            this.lbl_empcity.Text = "EmployeeCity";
            // 
            // lbl_emppassword
            // 
            this.lbl_emppassword.AutoSize = true;
            this.lbl_emppassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_emppassword.Location = new System.Drawing.Point(50, 184);
            this.lbl_emppassword.Name = "lbl_emppassword";
            this.lbl_emppassword.Size = new System.Drawing.Size(185, 25);
            this.lbl_emppassword.TabIndex = 4;
            this.lbl_emppassword.Text = "EmployeePassword";
            // 
            // txt_empname
            // 
            this.txt_empname.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_empname.Location = new System.Drawing.Point(261, 64);
            this.txt_empname.Name = "txt_empname";
            this.txt_empname.Size = new System.Drawing.Size(177, 30);
            this.txt_empname.TabIndex = 6;
            // 
            // txt_empcity
            // 
            this.txt_empcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_empcity.Location = new System.Drawing.Point(261, 125);
            this.txt_empcity.Name = "txt_empcity";
            this.txt_empcity.Size = new System.Drawing.Size(111, 30);
            this.txt_empcity.TabIndex = 7;
            // 
            // txt_emppassword
            // 
            this.txt_emppassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_emppassword.Location = new System.Drawing.Point(261, 188);
            this.txt_emppassword.Name = "txt_emppassword";
            this.txt_emppassword.Size = new System.Drawing.Size(111, 30);
            this.txt_emppassword.TabIndex = 8;
            // 
            // btn_newemp
            // 
            this.btn_newemp.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newemp.Location = new System.Drawing.Point(55, 291);
            this.btn_newemp.Name = "btn_newemp";
            this.btn_newemp.Size = new System.Drawing.Size(149, 64);
            this.btn_newemp.TabIndex = 9;
            this.btn_newemp.Text = "NewEmployee";
            this.btn_newemp.UseVisualStyleBackColor = true;
            this.btn_newemp.Click += new System.EventHandler(this.btn_newemp_Click);
            // 
            // btn_reset
            // 
            this.btn_reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reset.Location = new System.Drawing.Point(325, 291);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(123, 64);
            this.btn_reset.TabIndex = 10;
            this.btn_reset.Text = "Reset";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(951, 390);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_newemp);
            this.Controls.Add(this.txt_emppassword);
            this.Controls.Add(this.txt_empcity);
            this.Controls.Add(this.txt_empname);
            this.Controls.Add(this.lbl_emppassword);
            this.Controls.Add(this.lbl_empcity);
            this.Controls.Add(this.lbl_empname);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_empname;
        private System.Windows.Forms.Label lbl_empcity;
        private System.Windows.Forms.Label lbl_emppassword;
        private System.Windows.Forms.TextBox txt_empname;
        private System.Windows.Forms.TextBox txt_empcity;
        private System.Windows.Forms.TextBox txt_emppassword;
        private System.Windows.Forms.Button btn_newemp;
        private System.Windows.Forms.Button btn_reset;
    }
}

