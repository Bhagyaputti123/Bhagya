﻿namespace Win_ADO
{
    partial class Frm_Find
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_emppassword = new System.Windows.Forms.TextBox();
            this.txt_empcity = new System.Windows.Forms.TextBox();
            this.txt_empname = new System.Windows.Forms.TextBox();
            this.lbl_emppassword = new System.Windows.Forms.Label();
            this.lbl_empcity = new System.Windows.Forms.Label();
            this.lbl_empname = new System.Windows.Forms.Label();
            this.lbl_empid = new System.Windows.Forms.Label();
            this.txt_empid = new System.Windows.Forms.TextBox();
            this.lbl_empdoj = new System.Windows.Forms.Label();
            this.txt_empDoj = new System.Windows.Forms.TextBox();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_find = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_emppassword
            // 
            this.txt_emppassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_emppassword.Location = new System.Drawing.Point(251, 172);
            this.txt_emppassword.Name = "txt_emppassword";
            this.txt_emppassword.Size = new System.Drawing.Size(187, 30);
            this.txt_emppassword.TabIndex = 16;
            // 
            // txt_empcity
            // 
            this.txt_empcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_empcity.Location = new System.Drawing.Point(251, 109);
            this.txt_empcity.Name = "txt_empcity";
            this.txt_empcity.Size = new System.Drawing.Size(177, 30);
            this.txt_empcity.TabIndex = 15;
            // 
            // txt_empname
            // 
            this.txt_empname.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_empname.Location = new System.Drawing.Point(251, 48);
            this.txt_empname.Name = "txt_empname";
            this.txt_empname.Size = new System.Drawing.Size(177, 30);
            this.txt_empname.TabIndex = 14;
            // 
            // lbl_emppassword
            // 
            this.lbl_emppassword.AutoSize = true;
            this.lbl_emppassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_emppassword.Location = new System.Drawing.Point(40, 168);
            this.lbl_emppassword.Name = "lbl_emppassword";
            this.lbl_emppassword.Size = new System.Drawing.Size(185, 25);
            this.lbl_emppassword.TabIndex = 13;
            this.lbl_emppassword.Text = "EmployeePassword";
            // 
            // lbl_empcity
            // 
            this.lbl_empcity.AutoSize = true;
            this.lbl_empcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_empcity.Location = new System.Drawing.Point(40, 105);
            this.lbl_empcity.Name = "lbl_empcity";
            this.lbl_empcity.Size = new System.Drawing.Size(133, 25);
            this.lbl_empcity.TabIndex = 12;
            this.lbl_empcity.Text = "EmployeeCity";
            // 
            // lbl_empname
            // 
            this.lbl_empname.AutoSize = true;
            this.lbl_empname.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_empname.Location = new System.Drawing.Point(35, 44);
            this.lbl_empname.Name = "lbl_empname";
            this.lbl_empname.Size = new System.Drawing.Size(148, 25);
            this.lbl_empname.TabIndex = 11;
            this.lbl_empname.Text = "Employeename";
            // 
            // lbl_empid
            // 
            this.lbl_empid.AutoSize = true;
            this.lbl_empid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_empid.Location = new System.Drawing.Point(40, 13);
            this.lbl_empid.Name = "lbl_empid";
            this.lbl_empid.Size = new System.Drawing.Size(118, 25);
            this.lbl_empid.TabIndex = 19;
            this.lbl_empid.Text = "EmployeeID";
            // 
            // txt_empid
            // 
            this.txt_empid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_empid.Location = new System.Drawing.Point(251, 13);
            this.txt_empid.Name = "txt_empid";
            this.txt_empid.Size = new System.Drawing.Size(177, 30);
            this.txt_empid.TabIndex = 20;
            // 
            // lbl_empdoj
            // 
            this.lbl_empdoj.AutoSize = true;
            this.lbl_empdoj.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_empdoj.Location = new System.Drawing.Point(45, 232);
            this.lbl_empdoj.Name = "lbl_empdoj";
            this.lbl_empdoj.Size = new System.Drawing.Size(140, 25);
            this.lbl_empdoj.TabIndex = 21;
            this.lbl_empdoj.Text = "EmployeeDOJ";
            // 
            // txt_empDoj
            // 
            this.txt_empDoj.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_empDoj.Location = new System.Drawing.Point(251, 232);
            this.txt_empDoj.Name = "txt_empDoj";
            this.txt_empDoj.Size = new System.Drawing.Size(177, 30);
            this.txt_empDoj.TabIndex = 22;
            // 
            // btn_delete
            // 
            this.btn_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.Location = new System.Drawing.Point(569, 298);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(142, 41);
            this.btn_delete.TabIndex = 24;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_find
            // 
            this.btn_find.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_find.Location = new System.Drawing.Point(569, 55);
            this.btn_find.Name = "btn_find";
            this.btn_find.Size = new System.Drawing.Size(128, 55);
            this.btn_find.TabIndex = 28;
            this.btn_find.Text = "Find";
            this.btn_find.UseVisualStyleBackColor = true;
            this.btn_find.Click += new System.EventHandler(this.btn_find_Click);
            // 
            // btn_update
            // 
            this.btn_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update.Location = new System.Drawing.Point(569, 172);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(128, 50);
            this.btn_update.TabIndex = 29;
            this.btn_update.Text = "Update";
            this.btn_update.UseVisualStyleBackColor = true;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // Frm_Find
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(824, 452);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.btn_find);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.txt_empDoj);
            this.Controls.Add(this.lbl_empdoj);
            this.Controls.Add(this.txt_empid);
            this.Controls.Add(this.lbl_empid);
            this.Controls.Add(this.txt_emppassword);
            this.Controls.Add(this.txt_empcity);
            this.Controls.Add(this.txt_empname);
            this.Controls.Add(this.lbl_emppassword);
            this.Controls.Add(this.lbl_empcity);
            this.Controls.Add(this.lbl_empname);
            this.Name = "Frm_Find";
            this.Text = "Frm_Find";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_emppassword;
        private System.Windows.Forms.TextBox txt_empcity;
        private System.Windows.Forms.TextBox txt_empname;
        private System.Windows.Forms.Label lbl_emppassword;
        private System.Windows.Forms.Label lbl_empcity;
        private System.Windows.Forms.Label lbl_empname;
        private System.Windows.Forms.Label lbl_empid;
        private System.Windows.Forms.TextBox txt_empid;
        private System.Windows.Forms.Label lbl_empdoj;
        private System.Windows.Forms.TextBox txt_empDoj;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_find;
        private System.Windows.Forms.Button btn_update;
    }
}