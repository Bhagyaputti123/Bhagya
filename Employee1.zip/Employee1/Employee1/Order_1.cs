﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee1
{
    class Order_1
    {
        private string orid;
        private string cname;
        private string iname;
        private int iprice;
        private int iqty;

        public Order_1(string orid, string cname, string iname,int iprice,int iqty)
        {
            this.orid = orid;
            this.cname = cname;
            this.iname = iname;
            this.iprice = iprice;
            this.iqty = iqty;
        }

        public int Getorderamount()
        {
            int total= iprice * iqty;
            return total;
        }
        public string GetDetails()
        {
            Console.WriteLine(orid + " " + cname + " " + iname + " " + iprice + " " + iqty);
        }
    }
}
